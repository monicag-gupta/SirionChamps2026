package com.example.demo.controller;

import com.example.demo.client.*;
import com.example.demo.dto.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class GatewayController {

    // Bring in all our phone lines
    @Autowired private CreateClient createClient;
    @Autowired private ReadClient readClient;
    @Autowired private UpdateClient updateClient;
    @Autowired private DeleteClient deleteClient;

    // When the webpage asks to GET employees, use the Read line
    @GetMapping
    public List<Employee> getEmployees() {
        return readClient.getAll();
    }

    // When the webpage asks to POST a new employee, use the Create line
    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee) {
        return createClient.createEmployee(employee);
    }

    // When the webpage asks to PUT (update) an employee, use the Update line
    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        return updateClient.updateEmployee(id, employee);
    }

    // When the webpage asks to DELETE an employee, use the Delete line
    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        deleteClient.deleteEmployee(id);
    }
}
