package com.example.demo.client;

import com.example.demo.dto.Employee;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "MS-CREATE") // Connects to your Create service
public interface CreateClient {
    @PostMapping("/create")
    Employee createEmployee(@RequestBody Employee employee);
}
