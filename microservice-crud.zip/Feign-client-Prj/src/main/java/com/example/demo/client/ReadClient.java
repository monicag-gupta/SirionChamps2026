package com.example.demo.client;

import com.example.demo.dto.Employee;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@FeignClient(name = "MS-READ")
public interface ReadClient {
    @GetMapping("/read")
    List<Employee> getAll();
}
