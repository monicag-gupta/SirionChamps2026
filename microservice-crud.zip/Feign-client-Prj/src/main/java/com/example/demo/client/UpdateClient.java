package com.example.demo.client;

import com.example.demo.dto.Employee;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "MS-UPDATE")
public interface UpdateClient {
    @PutMapping("/update/{id}")
    Employee updateEmployee(@PathVariable("id") Long id, @RequestBody Employee employee);
}
