package com.example.demo.controller;

import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/delete")
public class DeleteController {

    @Autowired
    private EmployeeRepository repo;
    
    // @DeleteMapping is used exclusively for destroying data
    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        // repo.deleteById() completely removes the row from the SQL table
        repo.deleteById(id);
    }
}
