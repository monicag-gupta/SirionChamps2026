package com.example.demo.controller;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/read")
public class ReadController {

    @Autowired
    private EmployeeRepository repo;
    
    // @GetMapping means this window only gives data OUT
    @GetMapping
    public List<Employee> getAll() {
        // repo.findAll() grabs every employee from the database at once
        return repo.findAll();
    }
}
