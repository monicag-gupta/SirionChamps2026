package com.example.demo.controller;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/update")
public class UpdateController {

    @Autowired
    private EmployeeRepository repo;
    
    // @PutMapping is used when we want to change existing data
    // {id} means we must provide the ID of the employee we want to change
    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee empDetails) {
        // Step 1: Find the existing employee in the database
        Employee existingEmployee = repo.findById(id).get();
        
        // Step 2: Change their name and department to the new details
        existingEmployee.setName(empDetails.getName());
        existingEmployee.setDepartment(empDetails.getDepartment());
        
        // Step 3: Save the updated employee back to the database
        return repo.save(existingEmployee);
    }
}
