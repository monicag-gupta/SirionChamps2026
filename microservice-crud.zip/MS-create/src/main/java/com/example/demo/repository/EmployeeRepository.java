// Note: Change this to match your actual project name!
package com.example.demo.repository; 

// This imports the Employee blueprint you just made
import com.example.demo.entity.Employee; 

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // You leave this completely empty! 
    // JpaRepository already has built-in methods like save(), findAll(), deleteById()
}
