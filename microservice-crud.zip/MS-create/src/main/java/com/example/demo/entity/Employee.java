package com.example.demo.entity;

// Note: Your package name at the top will be whatever you named your project 
// in Spring Initializr (e.g., package com.example.mscreate.entity;)

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String department;

    // 1. A blank, empty constructor is required by Spring/SQL to create the object behind the scenes
    public Employee() {
    }

    // 2. A constructor with fields to make it easy for us to create new Employees in code
    public Employee(String name, String department) {
        this.name = name;
        this.department = department;
    }

    // 3. Getters and Setters 
    // These allow the other parts of your app to safely view and change the data
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}