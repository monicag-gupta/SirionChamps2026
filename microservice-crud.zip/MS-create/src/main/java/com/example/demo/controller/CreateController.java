package com.example.demo.controller; 

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController // Tells Spring this is a Drive-Thru window
@RequestMapping("/create") // The URL path people will visit to use this
public class CreateController {

    @Autowired // This automatically connects our Database Manager (Repository)
    private EmployeeRepository repo;
    
    // @PostMapping means this window only accepts data being SENT to it
    // @RequestBody grabs the employee data from the incoming request
    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        // repo.save() is a built-in magic command that writes to the SQL database!
        return repo.save(employee);
    }
}
