package com.example.service;

import com.example.model.Project;
import com.example.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProjectService {
    @Autowired
    private ProjectRepository repository;

    public Project createProject(Project p) { return repository.save(p); }
    public List<Project> getAllProjects() { return repository.findAll(); }
    public Project getProjectById(Long id) { return repository.findById(id).orElse(null); }
    
    public Project updateProject(Long id, Project details) {
        Project p = repository.findById(id).orElse(null);
        if(p != null) {
            p.setPname(details.getPname());
            p.setDuration(details.getDuration());
            p.setPmngr(details.getPmngr());
            p.setPLanguage(details.getPLanguage());
            return repository.save(p);
        }
        return null;
    }
    
    public void deleteProject(Long id) { repository.deleteById(id); }

    // Reports Logic
    public List<Project> getProjectsByManager(String manager) { return repository.findByPmngr(manager); }
    public List<Project> getProjectsByLanguage(String lang) { return repository.findBypLanguage(lang); }
    public List<Object[]> getTeamCountReport() { return repository.getProjectTeamCountReport(); }
}