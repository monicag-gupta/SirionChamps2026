package com.example.controller;

import com.example.model.Project;
import com.example.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    @Autowired
    private ProjectService service;

    @PostMapping
    public Project create(@RequestBody Project project) { return service.createProject(project); }

    @GetMapping
    public List<Project> getAll() { return service.getAllProjects(); }

    @GetMapping("/{id}")
    public ResponseEntity<Project> getById(@PathVariable Long id) {
        Project p = service.getProjectById(id);
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Project> update(@PathVariable Long id, @RequestBody Project project) {
        Project updated = service.updateProject(id, project);
        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteProject(id);
        return ResponseEntity.noContent().build();
    }

    // --- REPORT ENDPOINTS ---
    @GetMapping("/report/manager/{manager}")
    public List<Project> getReportByManager(@PathVariable String manager) {
        return service.getProjectsByManager(manager);
    }

    @GetMapping("/report/language/{lang}")
    public List<Project> getReportByLanguage(@PathVariable String lang) {
        return service.getProjectsByLanguage(lang);
    }

    @GetMapping("/report/team-count")
    public List<Object[]> getTeamCountReport() {
        return service.getTeamCountReport();
    }
}