package com.example.controller;

import com.example.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> loginData) {
        String username = loginData.get("username");
        String password = loginData.get("password");

        // Simulating manager verification for simplicity
        if ("manager".equals(username) && "password123".equals(password)) {
            String token = jwtUtils.generateToken(username);
            return Map.of("token", token);
        }
        throw new RuntimeException("Invalid Credentials");
    }
}