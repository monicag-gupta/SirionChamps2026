package com.example.repository;

import com.example.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    
    // Matches: repository.findByPmngr(manager)
    List<Project> findByPmngr(String pmngr);
    
    // Matches: repository.findBypLanguage(lang)
    List<Project> findBypLanguage(String pLanguage);

    // Matches: repository.getProjectTeamCountReport()
    @Query("SELECT p.pname, p.pmngr, COUNT(e.eid) FROM Project p LEFT JOIN p.teamMembers e GROUP BY p.pid, p.pname, p.pmngr")
    List<Object[]> getProjectTeamCountReport();
}