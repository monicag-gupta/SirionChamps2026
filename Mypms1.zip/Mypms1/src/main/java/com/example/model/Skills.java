package com.example.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "skills")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Skills {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sid;
    
    @Column(name = "s_name")
    private String sName;
    
    @ManyToOne
    @JoinColumn(name = "eid", nullable = false)
    private Employee employee;
}