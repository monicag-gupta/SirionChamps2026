package com.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity
@Table(name = "emp")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eid;
    
    private String ename;

    // Establishing the Team association (Many-to-Many relationship with Project)
    @ManyToMany(mappedBy = "teamMembers")
    private Set<Project> projects;
}