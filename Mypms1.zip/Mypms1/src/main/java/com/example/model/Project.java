package com.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity
@Table(name = "project")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pid;
    
    private String pname;
    private int duration;
    private String pmngr;
    
    @Column(name = "p_language")
    private String pLanguage;

    @ManyToMany
    @JoinTable(
        name = "team",
        joinColumns = @JoinColumn(name = "pid"),
        inverseJoinColumns = @JoinColumn(name = "eid")
    )
    private Set<Employee> teamMembers;

    // --- MANUALLY ADDED GETTERS & SETTERS TO BYPASS ECLIPSE LOMBOK ISSUES ---
    public Long getPid() { return pid; }
    public void setPid(Long pid) { this.pid = pid; }

    public String getPname() { return pname; }
    public void setPname(String pname) { this.pname = pname; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public String getPmngr() { return pmngr; }
    public void setPmngr(String pmngr) { this.pmngr = pmngr; }

    public String getPLanguage() { return pLanguage; }
    public void setPLanguage(String pLanguage) { this.pLanguage = pLanguage; }

    public Set<Employee> getTeamMembers() { return teamMembers; }
    public void setTeamMembers(Set<Employee> teamMembers) { this.teamMembers = teamMembers; }
}