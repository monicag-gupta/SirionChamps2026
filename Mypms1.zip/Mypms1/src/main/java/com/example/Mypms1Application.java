package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mypms1Application {

	public static void main(String[] args) {
		SpringApplication.run(Mypms1Application.class, args);
	}

}
