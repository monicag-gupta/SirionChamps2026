package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.UserRepository;



@Service
public class DeleteUserService {


    @Autowired
    private UserRepository repository;



    public String deleteUser(Long id) {


        if(repository.existsById(id)) {


            repository.deleteById(id);

            return "User deleted successfully";

        }


        return "User not found";

    }

}