package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.service.DeleteUserService;


@RestController
@RequestMapping("/users")
public class DeleteController {


    @Autowired
    private DeleteUserService service;


    @DeleteMapping("/{id}")
    public String deleteUser(
            @PathVariable Long id) {


        return service.deleteUser(id);

    }

}