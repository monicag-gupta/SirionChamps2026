package com.example.entity;


import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Team {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;



@ManyToOne

@JoinColumn(name="eid")

private Employee employee;



@ManyToOne

@JoinColumn(name="pid")

private Project project;



public Long getId() {
	return id;
}



public void setId(Long id) {
	this.id = id;
}



public Employee getEmployee() {
	return employee;
}



public void setEmployee(Employee employee) {
	this.employee = employee;
}



public Project getProject() {
	return project;
}



public void setProject(Project project) {
	this.project = project;
}


}