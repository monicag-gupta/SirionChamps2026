package com.example.entity;


import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Skill {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;


private String sName;


@ManyToOne

@JoinColumn(name="eid")

private Employee employee;


public Long getId() {
	return id;
}


public void setId(Long id) {
	this.id = id;
}


public String getsName() {
	return sName;
}


public void setsName(String sName) {
	this.sName = sName;
}


public Employee getEmployee() {
	return employee;
}


public void setEmployee(Employee employee) {
	this.employee = employee;
}


}