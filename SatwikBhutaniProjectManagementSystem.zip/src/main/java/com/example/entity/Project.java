package com.example.entity;



import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Project {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long pid;


private String pname;


private int duration;


private String pmngr;


private String PLanguage;


public Long getPid() {
	return pid;
}


public void setPid(Long pid) {
	this.pid = pid;
}


public String getPname() {
	return pname;
}


public void setPname(String pname) {
	this.pname = pname;
}


public int getDuration() {
	return duration;
}


public void setDuration(int duration) {
	this.duration = duration;
}


public String getPmngr() {
	return pmngr;
}


public void setPmngr(String pmngr) {
	this.pmngr = pmngr;
}


public String getPLanguage() {
	return PLanguage;
}


public void setPLanguage(String pLanguage) {
	PLanguage = pLanguage;
}


}