package com.example.entity;



import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Employee {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long eid;


private String ename;


public Long getEid() {
	return eid;
}


public void setEid(Long eid) {
	this.eid = eid;
}


public String getEname() {
	return ename;
}


public void setEname(String ename) {
	this.ename = ename;
}


}