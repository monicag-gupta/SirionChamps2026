package com.example.dto;

public class ProjectReportDTO {

    private Long pid;
    private String pname;
    private String pmngr;
    private String pLanguage;
    private int duration;

    public ProjectReportDTO() {
    }

    public ProjectReportDTO(Long pid, String pname, String pmngr,
                            String pLanguage, int duration) {
        this.pid = pid;
        this.pname = pname;
        this.pmngr = pmngr;
        this.pLanguage = pLanguage;
        this.duration = duration;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPmngr() {
        return pmngr;
    }

    public void setPmngr(String pmngr) {
        this.pmngr = pmngr;
    }

    public String getPLanguage() {
        return pLanguage;
    }

    public void setPLanguage(String pLanguage) {
        this.pLanguage = pLanguage;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}