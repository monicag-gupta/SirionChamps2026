package com.example.controller;



import java.util.List;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.example.entity.Project;
import com.example.entity.Team;
import com.example.service.ProjectService;



@RestController
@RequestMapping("/projects")
public class ProjectController {



private final ProjectService service;



public ProjectController(ProjectService service){

    this.service=service;

}




@PostMapping
public ResponseEntity<Project> create(
        @RequestBody Project project){


return ResponseEntity.ok(
        service.createProject(project));

}




@GetMapping
public List<Project> getAll(){

return service.getAllProjects();

}




@GetMapping("/{id}")
public Project getById(
        @PathVariable Long id){

return service.getProjectById(id);

}




@PutMapping("/{id}")
public Project update(
        @PathVariable Long id,
        @RequestBody Project project){


return service.updateProject(id,project);

}




@DeleteMapping("/{id}")
public String delete(
        @PathVariable Long id){


return service.deleteProject(id);

}





@PostMapping("/{pid}/employee/{eid}")
public Team assignEmployee(

@PathVariable Long pid,

@PathVariable Long eid){


return service.assignEmployeeToProject(
        eid,pid);

}





@GetMapping("/{pid}/team")
public List<Team> team(
        @PathVariable Long pid){


return service.getProjectTeam(pid);

}



}