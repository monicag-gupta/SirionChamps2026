package com.example.controller;



import java.util.List;


import org.springframework.web.bind.annotation.*;


import com.example.entity.Employee;
import com.example.entity.Skill;
import com.example.service.EmployeeService;



@RestController
@RequestMapping("/employees")
public class EmployeeController {



private final EmployeeService service;



public EmployeeController(EmployeeService service){

this.service=service;

}





@PostMapping
public Employee add(
@RequestBody Employee employee){

return service.createEmployee(employee);

}





@GetMapping
public List<Employee> all(){

return service.getAllEmployees();

}





@GetMapping("/{id}")
public Employee get(
@PathVariable Long id){

return service.getEmployeeById(id);

}





@PutMapping("/{id}")
public Employee update(

@PathVariable Long id,

@RequestBody Employee employee){

return service.updateEmployee(id,employee);

}





@DeleteMapping("/{id}")
public String delete(
@PathVariable Long id){

return service.deleteEmployee(id);

}






@PostMapping("/{eid}/skills")
public Skill addSkill(

@PathVariable Long eid,

@RequestBody Skill skill){


return service.addSkill(eid,skill);

}




@GetMapping("/{eid}/skills")
public List<Skill> skills(
@PathVariable Long eid){


return service.getEmployeeSkills(eid);

}




@DeleteMapping("/skills/{sid}")
public String deleteSkill(
@PathVariable Long sid){


return service.deleteSkill(sid);

}


}