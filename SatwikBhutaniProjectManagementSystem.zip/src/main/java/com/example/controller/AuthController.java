package com.example.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.example.dto.LoginRequest;
import com.example.dto.LoginResponse;
import com.example.dto.RegisterRequest;
import com.example.entity.User;
import com.example.repository.UserRepository;
import com.example.service.JwtService;



@RestController
@RequestMapping("/auth")
public class AuthController {



    private final AuthenticationManager authenticationManager;

    private final JwtService jwtService;

    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;




    public AuthController(
            AuthenticationManager authenticationManager,
            JwtService jwtService,
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {


        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

    }




    // REGISTER API

    @PostMapping("/register")
    public ResponseEntity<String> register(
            @RequestBody RegisterRequest request) {



        if(userRepository
                .findByUsername(request.getUsername())
                .isPresent()) {


            return ResponseEntity
                    .badRequest()
                    .body("Username already exists");

        }




        User user = new User();


        user.setUsername(
                request.getUsername());


        user.setPassword(
                passwordEncoder.encode(
                        request.getPassword()));



        user.setRole(
                request.getRole());



        userRepository.save(user);



        return ResponseEntity.ok(
                "User registered successfully");

    }






    // LOGIN API

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(
            @RequestBody LoginRequest request) {



        authenticationManager.authenticate(

                new UsernamePasswordAuthenticationToken(

                        request.getUsername(),

                        request.getPassword()

                )

        );



        String token =
                jwtService.generateToken(
                        request.getUsername());



        return ResponseEntity.ok(

                new LoginResponse(token)

        );

    }



}