package com.example.controller;



import java.util.List;


import org.springframework.web.bind.annotation.*;


import com.example.dto.ProjectReportDTO;
import com.example.entity.Project;
import com.example.service.ReportService;



@RestController
@RequestMapping("/reports")
public class ReportController {



private final ReportService service;



public ReportController(ReportService service){

this.service=service;

}





@GetMapping("/projects")
public List<ProjectReportDTO> projectReport(){


return service.getProjectReport();

}





@GetMapping("/manager/{name}")
public List<Project> byManager(

@PathVariable String name){


return service.getProjectsByManager(name);

}





@GetMapping("/language/{name}")
public List<Project> byLanguage(

@PathVariable String name){


return service.getProjectsByLanguage(name);

}



}