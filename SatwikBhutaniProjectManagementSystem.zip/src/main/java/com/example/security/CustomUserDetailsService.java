package com.example.security;



import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


import com.example.entity.User;
import com.example.repository.UserRepository;



@Service
public class CustomUserDetailsService 
        implements UserDetailsService {



private final UserRepository repository;



public CustomUserDetailsService(
        UserRepository repository){

    this.repository=repository;

}





@Override
public UserDetails loadUserByUsername(
        String username)
        throws UsernameNotFoundException {



User user =
        repository.findByUsername(username)

        .orElseThrow(
        () -> new UsernameNotFoundException(
        "User not found"));




return org.springframework.security.core.userdetails.User

        .builder()

        .username(user.getUsername())

        .password(user.getPassword())

        .roles(user.getRole())

        .build();


}


}