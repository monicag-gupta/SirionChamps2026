package com.example.service;




import java.util.List;


import org.springframework.stereotype.Service;


import com.example.entity.Employee;
import com.example.entity.Skill;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.EmployeeRepository;
import com.example.repository.SkillRepository;



@Service
public class EmployeeService {



    private final EmployeeRepository employeeRepository;

    private final SkillRepository skillRepository;




    public EmployeeService(
            EmployeeRepository employeeRepository,
            SkillRepository skillRepository) {


        this.employeeRepository = employeeRepository;

        this.skillRepository = skillRepository;

    }




    // CREATE EMPLOYEE


    public Employee createEmployee(Employee employee) {


        return employeeRepository.save(employee);

    }





    // GET ALL EMPLOYEE


    public List<Employee> getAllEmployees() {


        return employeeRepository.findAll();

    }





    // GET EMPLOYEE BY ID


    public Employee getEmployeeById(Long eid) {


        return employeeRepository.findById(eid)

                .orElseThrow(
                () -> new ResourceNotFoundException(
                "Employee not found"));

    }






    // UPDATE EMPLOYEE


    public Employee updateEmployee(
            Long eid,
            Employee employee) {


        Employee old =
                getEmployeeById(eid);



        old.setEname(employee.getEname());



        return employeeRepository.save(old);

    }





    // DELETE EMPLOYEE


    public String deleteEmployee(Long eid) {


        Employee employee =
                getEmployeeById(eid);


        employeeRepository.delete(employee);



        return "Employee deleted successfully";

    }





    // ADD SKILL TO EMPLOYEE


    public Skill addSkill(
            Long eid,
            Skill skill) {



        Employee employee =
                getEmployeeById(eid);



        skill.setEmployee(employee);



        return skillRepository.save(skill);

    }





    // GET EMPLOYEE SKILLS


    public List<Skill> getEmployeeSkills(Long eid) {


        Employee employee =
                getEmployeeById(eid);



        return skillRepository.findAll()
                .stream()

                .filter(skill ->
                skill.getEmployee()
                .getEid()
                .equals(employee.getEid()))

                .toList();

    }





    // DELETE SKILL


    public String deleteSkill(Long skillId) {


        skillRepository.deleteById(skillId);


        return "Skill deleted successfully";

    }



}