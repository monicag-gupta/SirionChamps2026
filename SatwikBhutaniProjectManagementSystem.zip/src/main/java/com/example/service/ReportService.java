package com.example.service;



import java.util.List;
import java.util.stream.Collectors;


import org.springframework.stereotype.Service;


import com.example.dto.ProjectReportDTO;
import com.example.entity.Project;
import com.example.repository.ProjectRepository;



@Service
public class ReportService {



    private final ProjectRepository projectRepository;



    public ReportService(
            ProjectRepository projectRepository) {

        this.projectRepository =
                projectRepository;

    }





    // PROJECT REPORT


    public List<ProjectReportDTO> getProjectReport(){



        List<Project> projects =
                projectRepository.findAll();




        return projects.stream()

                .map(project ->

                new ProjectReportDTO(

                project.getPid(),

                project.getPname(),

                project.getPmngr(),

                project.getPLanguage(),

                project.getDuration()

                ))

                .collect(Collectors.toList());

    }






    // PROJECTS BY MANAGER


    public List<Project> getProjectsByManager(
            String manager){


        return projectRepository.findAll()

                .stream()

                .filter(p ->
                p.getPmngr()
                .equalsIgnoreCase(manager))

                .toList();

    }






    // PROJECTS BY LANGUAGE


    public List<Project> getProjectsByLanguage(
            String language){


        return projectRepository.findAll()

                .stream()

                .filter(p ->
                p.getPLanguage()
                .equalsIgnoreCase(language))

                .toList();

    }



}