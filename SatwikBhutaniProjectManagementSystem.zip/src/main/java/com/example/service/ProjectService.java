package com.example.service;



import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Employee;
import com.example.entity.Project;
import com.example.entity.Team;
import com.example.exception.ResourceNotFoundException;
import com.example.repository.EmployeeRepository;
import com.example.repository.ProjectRepository;
import com.example.repository.TeamRepository;


@Service
public class ProjectService {


    private final ProjectRepository projectRepository;

    private final EmployeeRepository employeeRepository;

    private final TeamRepository teamRepository;



    public ProjectService(
            ProjectRepository projectRepository,
            EmployeeRepository employeeRepository,
            TeamRepository teamRepository) {

        this.projectRepository = projectRepository;
        this.employeeRepository = employeeRepository;
        this.teamRepository = teamRepository;

    }



    // CREATE PROJECT

    public Project createProject(Project project) {

        return projectRepository.save(project);

    }



    // GET ALL PROJECTS

    public List<Project> getAllProjects() {

        return projectRepository.findAll();

    }



    // GET PROJECT BY ID

    public Project getProjectById(Long pid) {


        return projectRepository.findById(pid)

                .orElseThrow(
                () -> new ResourceNotFoundException(
                        "Project not found with id : " + pid));

    }



    // UPDATE PROJECT

    public Project updateProject(Long pid, Project project) {


        Project oldProject = getProjectById(pid);


        oldProject.setPname(project.getPname());

        oldProject.setDuration(project.getDuration());

        oldProject.setPmngr(project.getPmngr());

        oldProject.setPLanguage(project.getPLanguage());


        return projectRepository.save(oldProject);

    }




    // DELETE PROJECT

    public String deleteProject(Long pid) {


        Project project = getProjectById(pid);


        projectRepository.delete(project);


        return "Project deleted successfully";

    }





    // ASSIGN EMPLOYEE TO PROJECT
    // Team table operation


    public Team assignEmployeeToProject(
            Long eid,
            Long pid) {



        Employee employee =
                employeeRepository.findById(eid)

                .orElseThrow(
                () -> new ResourceNotFoundException(
                "Employee not found"));



        Project project =
                getProjectById(pid);



        Team team = new Team();


        team.setEmployee(employee);

        team.setProject(project);



        return teamRepository.save(team);

    }




    // GET PROJECT TEAM


    public List<Team> getProjectTeam(Long pid) {


        Project project = getProjectById(pid);


        return teamRepository.findAll()
                .stream()
                .filter(t ->
                t.getProject()
                .getPid()
                .equals(project.getPid()))

                .toList();

    }



}