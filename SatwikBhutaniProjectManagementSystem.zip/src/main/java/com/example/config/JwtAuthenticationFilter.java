package com.example.config;



import java.io.IOException;
import java.util.Collections;


import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;


import com.example.service.JwtService;


import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@Component
public class JwtAuthenticationFilter 
        extends OncePerRequestFilter {



    private final JwtService jwtService;




    public JwtAuthenticationFilter(
            JwtService jwtService) {


        this.jwtService = jwtService;

    }





    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)

            throws ServletException, IOException {



        String path =
                request.getServletPath();



        // Skip JWT checking for login/register

        if(path.startsWith("/auth")) {


            filterChain.doFilter(
                    request,
                    response);

            return;

        }




        String authHeader =
                request.getHeader("Authorization");



        String username = null;

        String token = null;




        if(authHeader != null &&
                authHeader.startsWith("Bearer ")) {



            token =
                authHeader.substring(7);



            try {


                username =
                    jwtService.extractUsername(token);



            }
            catch(Exception e) {


                response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED);


                return;

            }


        }






        if(username != null &&

            SecurityContextHolder
            .getContext()
            .getAuthentication()==null) {




            UsernamePasswordAuthenticationToken authentication =

                new UsernamePasswordAuthenticationToken(

                        username,

                        null,

                        Collections.emptyList()

                );




            authentication.setDetails(

                    new WebAuthenticationDetailsSource()

                    .buildDetails(request)

            );



            SecurityContextHolder
            .getContext()
            .setAuthentication(authentication);



        }




        filterChain.doFilter(
                request,
                response);



    }


}