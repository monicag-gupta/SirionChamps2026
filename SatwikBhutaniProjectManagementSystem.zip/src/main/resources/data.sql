INSERT INTO user
(username,password,role)
VALUES
(
'admin',
'$2a$10$7QJ7vX2vXxV8r5V5kR8r8O6f9F8n6bY8u9X9xY4a1',
'ADMIN'
);


INSERT INTO employee
(ename)
VALUES
('Rahul'),
('Amit'),
('Priya');



INSERT INTO project
(pname,duration,pmngr,PLanguage)
VALUES
('Bank Application',
12,
'Raj',
'Java'),


('Ecommerce Portal',
8,
'Neha',
'Python');