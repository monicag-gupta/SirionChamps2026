package com.example.demo.config;

import java.util.Date;

import org.jspecify.annotations.Nullable;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {

    private String secret = "1234567890123456789012345678901234567890123456789012345678901234";
;

    private long expiration = 1000 * 60 * 60; // 1 hour


    // Generate Token
    public String generateToken(@Nullable Object object) {

        return Jwts.builder()
                .setSubject((String) object)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
    }


    // Extract Username
    public String extractUsername(String token) {

        Claims claims = Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token)
                .getBody();

        return claims.getSubject();
    }


    // Validate Token
    public boolean validateToken(String token) {

        try {

            Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token);

            return true;

        } catch(Exception e) {

            return false;
        }
    }
}