package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Team;

@Repository
public interface TeamRepository extends JpaRepository<Team, Integer> {

    List<Team> findByEid(Integer eid);

    List<Team> findByPid(Integer pid);

}