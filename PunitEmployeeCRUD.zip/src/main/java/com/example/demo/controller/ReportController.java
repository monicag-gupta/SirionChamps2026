package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Project;
import com.example.demo.entity.Skill;
import com.example.demo.entity.Team;
import com.example.demo.service.ReportService;



@RestController
@RequestMapping("/reports")
public class ReportController {



    @Autowired
    private ReportService reportService;



    // Total Projects Report
    @GetMapping("/totalProjects")
    public long totalProjects(){

        return reportService.totalProjects();
    }



    // Total Employees Report
    @GetMapping("/totalEmployees")
    public long totalEmployees(){

        return reportService.totalEmployees();
    }



    // Total Skills Report
    @GetMapping("/totalSkills")
    public long totalSkills(){

        return reportService.totalSkills();
    }



    // Total Team Members Report
    @GetMapping("/totalTeamMembers")
    public long totalTeamMembers(){

        return reportService.totalTeamMembers();
    }



    // Project Report
    @GetMapping("/projects")
    public List<Project> projectReport(){

        return reportService.getProjects();
    }



    // Employee Report
    @GetMapping("/employees")
    public List<Employee> employeeReport(){

        return reportService.getEmployees();
    }



    // Skill Report
    @GetMapping("/skills")
    public List<Skill> skillReport(){

        return reportService.getSkills();
    }



    // Team Report
    @GetMapping("/teams")
    public List<Team> teamReport(){

        return reportService.getTeams();
    }

}