package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Project;
import com.example.demo.service.ProjectService;



@RestController
@RequestMapping("/projects")
public class ProjectController {



    @Autowired
    private ProjectService projectService;



    // CREATE PROJECT
    @PostMapping
    public Project addProject(
            @RequestBody Project project) {

        return projectService.saveProject(project);
    }



    // GET ALL PROJECTS
    @GetMapping
    public List<Project> getAllProjects(){

        return projectService.getAllProjects();
    }



    // GET PROJECT BY ID
    @GetMapping("/{id}")
    public Project getProjectById(
            @PathVariable Integer id){

        return projectService.getProjectById(id);
    }



    // UPDATE PROJECT
    @PutMapping("/{id}")
    public Project updateProject(
            @PathVariable Integer id,
            @RequestBody Project project){


        project.setPid(id);

        return projectService.updateProject(project);
    }




    // DELETE PROJECT
    @DeleteMapping("/{id}")
    public String deleteProject(
            @PathVariable Integer id){


        projectService.deleteProject(id);

        return "Project deleted successfully";
    }

}