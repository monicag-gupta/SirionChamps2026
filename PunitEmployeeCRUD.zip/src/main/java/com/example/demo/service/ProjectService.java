package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Project;
import com.example.demo.repository.ProjectRepository;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    // Add Project
    public Project saveProject(Project project) {
        return projectRepository.save(project);
    }

    // Get All Projects
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    // Get Project by ID
    public Project getProjectById(Integer pid) {
        return projectRepository.findById(pid).orElse(null);
    }

    // Update Project
    public Project updateProject(Project project) {
        return projectRepository.save(project);
    }

    // Delete Project
    public void deleteProject(Integer pid) {
        projectRepository.deleteById(pid);
    }
}