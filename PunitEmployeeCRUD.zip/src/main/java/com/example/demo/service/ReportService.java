package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.entity.Project;
import com.example.demo.entity.Skill;
import com.example.demo.entity.Team;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.repository.SkillRepository;
import com.example.demo.repository.TeamRepository;

@Service
public class ReportService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private SkillRepository skillRepository;

    @Autowired
    private TeamRepository teamRepository;

    // Total Projects
    public long totalProjects() {
        return projectRepository.count();
    }

    // Total Employees
    public long totalEmployees() {
        return employeeRepository.count();
    }

    // Total Skills
    public long totalSkills() {
        return skillRepository.count();
    }

    // Total Team Members
    public long totalTeamMembers() {
        return teamRepository.count();
    }

    // Project List
    public List<Project> getProjects() {
        return projectRepository.findAll();
    }

    // Employee List
    public List<Employee> getEmployees() {
        return employeeRepository.findAll();
    }

    // Skill List
    public List<Skill> getSkills() {
        return skillRepository.findAll();
    }

    // Team List
    public List<Team> getTeams() {
        return teamRepository.findAll();
    }
}