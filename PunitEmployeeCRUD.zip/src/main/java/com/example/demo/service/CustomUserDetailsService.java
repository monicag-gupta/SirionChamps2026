package com.example.demo.service;

import java.util.Collections;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class CustomUserDetailsService implements UserDetailsService {


    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {


        if(username.equals("admin")) {

            return User.builder()
                    .username("admin")
                    .password("{noop}admin")
                    .roles("USER")
                    .build();

        }


        throw new UsernameNotFoundException("User not found");

    }

}