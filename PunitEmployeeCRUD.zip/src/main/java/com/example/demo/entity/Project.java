package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pid;

    private String pname;

    private Integer duration;

    private String pmngr;

    private String pLanguage;

	public void setPid(Integer id) {
		// TODO Auto-generated method stub
		
	}
}