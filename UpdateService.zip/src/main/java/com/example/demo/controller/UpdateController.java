package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;
import com.example.demo.service.UpdateUserService;


@RestController
@RequestMapping("/users")
public class UpdateController {


    @Autowired
    private UpdateUserService service;


    @PutMapping("/{id}")
    public User updateUser(
            @PathVariable Long id,
            @RequestBody User user) {


        return service.updateUser(id,user);

    }

}