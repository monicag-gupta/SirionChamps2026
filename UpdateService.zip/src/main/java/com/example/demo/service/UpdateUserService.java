package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;



@Service
public class UpdateUserService {


    @Autowired
    private UserRepository repository;



    public User updateUser(Long id, User user) {


        User existingUser = repository.findById(id)
                .orElse(null);


        if(existingUser != null) {


            existingUser.setName(user.getName());

            existingUser.setEmail(user.getEmail());


            return repository.save(existingUser);

        }


        return null;

    }

}