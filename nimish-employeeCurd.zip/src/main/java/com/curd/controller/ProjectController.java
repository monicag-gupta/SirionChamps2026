package com.curd.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.curd.entity.Project;
import com.curd.service.ProjectService;

@RestController
@RequestMapping("/projects")
public class ProjectController {

	private final ProjectService service;

	public ProjectController(ProjectService service) {
		this.service = service;
	}

	@PostMapping
	public Project add(@RequestBody Project p) {

		return service.save(p);
	}

	@GetMapping
	public List<Project> getAll() {

		return service.getAll();
	}

	@GetMapping("/{id}")
	public Project get(@PathVariable int id) {

		return service.getById(id);
	}

	@DeleteMapping("/{id}")
	public String delete(@PathVariable int id) {

		service.delete(id);

		return "Deleted";
	}

}