package com.curd.controller;


import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;


import com.curd.dto.*;
import com.curd.entity.User;
import com.curd.repository.UserRepository;
import com.curd.security.JwtService;



@RestController
@RequestMapping("/auth")
public class AuthController {


    private AuthenticationManager manager;

    private JwtService jwt;

    private UserRepository userRepository;

    private PasswordEncoder passwordEncoder;



    public AuthController(
            AuthenticationManager manager,
            JwtService jwt,
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {


        this.manager = manager;
        this.jwt = jwt;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

    }



    @PostMapping("/register")
    public String register(
            @RequestBody RegisterRequest request) {


        User user = new User();


        user.setUsername(request.getUsername());


        user.setPassword(
                passwordEncoder.encode(
                        request.getPassword()
                )
        );


        user.setRole(request.getRole());


        userRepository.save(user);


        return "User Registered Successfully";

    }




    @PostMapping("/login")
    public JwtResponse login(
            @RequestBody LoginRequest request) {


        manager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );


        String token =
                jwt.generateToken(
                        request.getUsername()
                );


        return new JwtResponse(token);

    }

}