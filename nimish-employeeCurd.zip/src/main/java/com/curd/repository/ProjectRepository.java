package com.curd.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.curd.entity.Project;


public interface ProjectRepository 
extends JpaRepository<Project,Integer>{

}