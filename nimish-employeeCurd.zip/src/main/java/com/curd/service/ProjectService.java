package com.curd.service;

import org.springframework.stereotype.Service;
import java.util.List;

import com.curd.entity.Project;
import com.curd.repository.ProjectRepository;

@Service
public class ProjectService {

	private final ProjectRepository repo;

	public ProjectService(ProjectRepository repo) {
		this.repo = repo;
	}

	public Project save(Project project) {

		return repo.save(project);
	}

	public List<Project> getAll() {

		return repo.findAll();
	}

	public Project getById(int id) {

		return repo.findById(id).orElse(null);
	}

	public void delete(int id) {

		repo.deleteById(id);
	}

}