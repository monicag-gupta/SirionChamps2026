package com.curd.service;

import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.curd.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	private UserRepository repo;

	public CustomUserDetailsService(UserRepository repo) {

		this.repo = repo;

	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		var user = repo.findByUsername(username).orElseThrow();

		return org.springframework.security.core.userdetails.User

				.withUsername(user.getUsername())

				.password(user.getPassword())

				.roles(user.getRole())

				.build();

	}

}