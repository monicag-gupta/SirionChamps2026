package com.curd.entity;


import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
public class Skills {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;


    private String sName;


    @ManyToOne
    @JoinColumn(name="eid")
    private Employee employee;

}