package com.curd.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;


@Entity
@Data
public class Employee {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eid;


    private String ename;


    @OneToMany(mappedBy = "employee",
               cascade = CascadeType.ALL)
    private List<Skills> skills;


    @ManyToMany
    @JoinTable(
        name="team",
        joinColumns=@JoinColumn(name="eid"),
        inverseJoinColumns=@JoinColumn(name="pid")
    )
    private List<Project> projects;

}