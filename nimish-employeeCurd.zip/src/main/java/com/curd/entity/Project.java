package com.curd.entity;


import jakarta.persistence.*;
import lombok.Data;
import java.util.List;


@Entity
@Data
public class Project {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int pid;


    private String pname;

    private String duration;

    private String pmgr;

    private String pLanguage;



    @ManyToMany(mappedBy = "projects")
    private List<Employee> employees;

}