package com.curd.security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

	// Minimum 32 characters for HS256
	private static final String SECRET = "mysecretkeymysecretkeymysecretkey1234";

	private final Key key = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));

	// Generate JWT Token
	public String generateToken(String username) {

		return Jwts.builder().setSubject(username).setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour
				.signWith(key, SignatureAlgorithm.HS256).compact();
	}

	// Extract Username
	public String extractUsername(String token) {

		return extractAllClaims(token).getSubject();
	}

	// Validate Token
	public boolean validateToken(String token, String username) {

		return extractUsername(token).equals(username) && !isTokenExpired(token);
	}

	// Check Expiration
	private boolean isTokenExpired(String token) {

		return extractAllClaims(token).getExpiration().before(new Date());
	}

	// Read Claims
	private Claims extractAllClaims(String token) {

		return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
	}
}