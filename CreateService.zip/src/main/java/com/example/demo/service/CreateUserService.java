package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;


@Service
public class CreateUserService {


    @Autowired
    private UserRepository repository;



    public User saveUser(User user) {

        return repository.save(user);

    }

}