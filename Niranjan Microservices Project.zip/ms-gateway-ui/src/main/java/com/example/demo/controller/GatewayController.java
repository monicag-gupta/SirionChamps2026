package com.example.demo.controller;

import com.example.demo.feign.EmployeeFeignClient.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/gateway")
public class GatewayController {

    @Autowired private CreateClient createClient;
    @Autowired private ReadClient readClient;
    @Autowired private UpdateClient updateClient;
    @Autowired private DeleteClient deleteClient;

    @PostMapping
    public Map<String, Object> create(@RequestBody Map<String, Object> emp) { return createClient.create(emp); }

    @GetMapping
    public List<Map<String, Object>> getAll() { return readClient.getAll(); }

    @PutMapping("/{id}")
    public Map<String, Object> update(@PathVariable Long id, @RequestBody Map<String, Object> emp) { return updateClient.update(id, emp); }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) { return deleteClient.delete(id); }
}