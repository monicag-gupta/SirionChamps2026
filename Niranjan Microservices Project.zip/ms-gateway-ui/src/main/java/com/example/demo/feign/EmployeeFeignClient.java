package com.example.demo.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

public class EmployeeFeignClient {

    @FeignClient(name = "ms-create")
    public interface CreateClient {
        @PostMapping("/employees")
        Map<String, Object> create(@RequestBody Map<String, Object> employee);
    }

    @FeignClient(name = "ms-read")
    public interface ReadClient {
        @GetMapping("/employees")
        List<Map<String, Object>> getAll();

        @GetMapping("/employees/{id}")
        Map<String, Object> getById(@PathVariable("id") Long id);
    }

    @FeignClient(name = "ms-update")
    public interface UpdateClient {
        @PutMapping("/employees/{id}")
        Map<String, Object> update(@PathVariable("id") Long id, @RequestBody Map<String, Object> employee);
    }

    @FeignClient(name = "ms-delete")
    public interface DeleteClient {
        @DeleteMapping("/employees/{id}")
        String delete(@PathVariable("id") Long id);
    }
}