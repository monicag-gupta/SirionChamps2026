package com.example.demo.controller;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeUpdateController {

    @Autowired
    private EmployeeRepository repository;

    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee empDetails) {
        Employee employee = repository.findById(id).orElseThrow(() -> new RuntimeException("Employee not found"));
        employee.setName(empDetails.getName());
        employee.setRole(empDetails.getRole());
        employee.setSalary(empDetails.getSalary());
        return repository.save(employee);
    }
}