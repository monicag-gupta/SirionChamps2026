package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.dto.EmployeeDTO;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    EmployeeService service;


    // Get all employees
    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getAllEmployees() {

        List<EmployeeDTO> employees = service.getAllEmployees();

        if (employees.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(employees, HttpStatus.OK);
    }


    // Get employee by id
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable int id) {

        EmployeeDTO employee = service.getEmployee(id);

        if (employee == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(employee, HttpStatus.OK);
    }


    // Create employee using REST JSON
    @PostMapping
    public ResponseEntity<EmployeeDTO> addEmployee(
            @RequestBody EmployeeDTO dto) {

        EmployeeDTO savedEmployee = service.addEmployee(dto);

        return new ResponseEntity<>(
                savedEmployee,
                HttpStatus.CREATED
        );
    }


    // Create employee using HTML GET form
    @GetMapping("/add")
    public ResponseEntity<EmployeeDTO> addEmployeeGet(
            @RequestParam int id,
            @RequestParam String name,
            @RequestParam double salary) {


        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(id);
        dto.setName(name);
        dto.setSalary(salary);


        EmployeeDTO savedEmployee = service.addEmployee(dto);

        return new ResponseEntity<>(
                savedEmployee,
                HttpStatus.CREATED
        );
    }


    // Create employee using HTML POST form
    @PostMapping("/addPost")
    public ResponseEntity<EmployeeDTO> addEmployeePost(
            @RequestParam int id,
            @RequestParam String name,
            @RequestParam double salary) {


        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(id);
        dto.setName(name);
        dto.setSalary(salary);


        EmployeeDTO savedEmployee = service.addEmployee(dto);

        return new ResponseEntity<>(
                savedEmployee,
                HttpStatus.CREATED
        );
    }


    // Update employee REST API
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeDTO> updateEmployee(
            @PathVariable int id,
            @RequestBody EmployeeDTO dto) {


        EmployeeDTO updated = service.updateEmployee(id, dto);


        if (updated == null) {
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND
            );
        }


        return new ResponseEntity<>(
                updated,
                HttpStatus.OK
        );
    }


    // Update using HTML form
    @GetMapping("/updateEmp")
    public ResponseEntity<EmployeeDTO> updateEmployee1(
            @RequestParam int id,
            @RequestParam String name,
            @RequestParam double salary) {


        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(id);
        dto.setName(name);
        dto.setSalary(salary);


        EmployeeDTO updated =
                service.updateEmployee(id, dto);


        if (updated == null) {
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND
            );
        }


        return new ResponseEntity<>(
                updated,
                HttpStatus.OK
        );
    }


    // Delete employee REST API
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(
            @PathVariable int id) {


        String result = service.deleteEmployee(id);


        if (result == null) {
            return new ResponseEntity<>(
                    "Employee not found",
                    HttpStatus.NOT_FOUND
            );
        }


        return new ResponseEntity<>(
                result,
                HttpStatus.OK
        );
    }


    // Delete using HTML form
    @GetMapping("/delEmp")
    public ResponseEntity<String> deleteEmployee1(
            @RequestParam int id) {


        String result = service.deleteEmployee(id);


        if (result == null) {
            return new ResponseEntity<>(
                    "Employee not found",
                    HttpStatus.NOT_FOUND
            );
        }


        return new ResponseEntity<>(
                result,
                HttpStatus.OK
        );
    }

}