package com.example.calculator;

import py4j.GatewayServer;

public class CalculatorGateway {

    private final Calculator calculator;

    public CalculatorGateway() {
        calculator = new Calculator();
    }

    public Calculator getCalculator() {
        return calculator;
    }

    public static void main(String[] args) {

        CalculatorGateway app = new CalculatorGateway();

        GatewayServer server = new GatewayServer(app);

        server.start();

        System.out.println("Py4J Gateway Server Started");
    }
}