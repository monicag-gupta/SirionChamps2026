<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Login Failed</title>
</head>
<body>
    <h2 style="color: red;">Authentication Failed</h2>
    <p>The username or password you entered is incorrect.</p>
    <a href="${pageContext.request.contextPath}/login">Go Back to Login</a>
</body>
</html>