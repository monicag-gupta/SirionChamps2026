<%-- <html>
<body>
	<h1>Congratulations!! the Company has processed your Application form successfully</h1>

	<h2>${msg}</h2>
	<h3><a href="admissionForm.html"> Back to Admission Form</a></h3>
</body>
</html> --%>

<html>
<body>
	<h1>Congratulations!! the Company has processed your Application form successfully</h1>

	<h2>${msg}</h2>
	
	<h3>
		<a href="admissionForm.html"> Back to Admission Form</a>
		<br><br>
		<a href="logout">Logout</a>	
	</h3>
	
</body>
</html>