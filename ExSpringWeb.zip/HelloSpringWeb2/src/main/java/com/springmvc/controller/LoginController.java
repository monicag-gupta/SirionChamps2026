////package com.springmvc.controller;
////import jakarta.servlet.http.HttpSession;
////import org.springframework.stereotype.Controller;
////import org.springframework.web.bind.annotation.*;
////@Controller
////public class LoginController {
////    @GetMapping("/login")
////    public String loginPage() {
////        return "login";    }
////    @PostMapping("/login")
////    public String login(@RequestParam("username") String username, @RequestParam("password") String password, HttpSession session) {
////        if (username.equals("admin") && password.equals("123")) {
////            session.setAttribute("loggedIn", true);
////            return "redirect:/admissionForm.html";
////        }
////        return "login";
////    }
////}
//
//package com.springmvc.controller;
//import jakarta.servlet.http.HttpSession;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//@Controller
//public class LoginController {
//    @GetMapping("/login")
//    public String loginPage() {
//        return "login";    }
//    @PostMapping("/login")
//    public String login(@RequestParam("username") String username, @RequestParam("password") String password, HttpSession session) {
//        if (username.equals("admin") && password.equals("123")) {
//            session.setAttribute("loggedIn", true);
//            return "redirect:/admissionForm.html";
//        }
//        return "login";
//    }
//    @GetMapping("/logout")
//    public String logout(HttpSession session) {
//        session.invalidate();
//        return "redirect:/";
//    }
//}


package com.springmvc.controller;

import com.springmvc.dao.UserDAO;
import com.springmvc.model.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private UserDAO userDAO;

    @GetMapping("/login")
    public String loginPage() {
        return "login";    
    }

    @PostMapping("/login")
    public String login(
            @RequestParam("username") String username, 
            @RequestParam("password") String password, 
            HttpSession session,
            Model model) {
        
        // Find user by username in database
        User user = userDAO.findByUsername(username);

        // Check if user exists and text password matches
        if (user != null && user.getPassword().equals(password)) {
            session.setAttribute("loggedIn", true);
            return "redirect:/admissionForm.html";
        }

        // Return to login.jsp showing an error message
        model.addAttribute("error", "Invalid username or password");
        return "error";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}