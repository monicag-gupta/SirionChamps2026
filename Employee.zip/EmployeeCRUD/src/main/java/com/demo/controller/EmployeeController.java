package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.demo.dto.EmployeeDTO;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    EmployeeService service;

//    @GetMapping
//    public List<EmployeeDTO> getAllEmployees() {
//
//        return service.getAllEmployees();
//
//    }
    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getAllEmployees() {
        List<EmployeeDTO> employees = service.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

//    @GetMapping("/{id}")
//    public EmployeeDTO getEmployee(@PathVariable int id) {
//
//        return service.getEmployee(id);
//
//    }
    
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable int id) {
        EmployeeDTO dto = service.getEmployee(id);
        if (dto != null) {
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

//    @PostMapping
//    public EmployeeDTO addEmployee(@RequestBody EmployeeDTO dto) {
//
//        return service.addEmployee(dto);
//
//    }
    @PostMapping
    public ResponseEntity<EmployeeDTO> addEmployee(@RequestBody EmployeeDTO dto) {
    	EmployeeDTO savedDto = service.addEmployee(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDto);
    }

//    @PutMapping("/{id}")
//    public EmployeeDTO updateEmployee(@PathVariable int id,
//                                      @RequestBody EmployeeDTO dto) {
//
//        return service.updateEmployee(id, dto);
//
//    }
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable int id,
          @RequestBody EmployeeDTO dto) {
    	EmployeeDTO updatedDto = service.updateEmployee(id,dto);
    	if (updatedDto != null) {
            return ResponseEntity.ok(updatedDto);
        } else {
            return ResponseEntity.notFound().build();
        }
			
	}
    

//    @DeleteMapping("/{id}")
//    public String deleteEmployee(@PathVariable int id) {
//
//        return service.deleteEmployee(id);
//
//    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<EmployeeDTO> deleteEmployee(@PathVariable int id) {
    	String result = service.deleteEmployee(id);
    	if (result != null && !result.toLowerCase().contains("not found")) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}



//package com.demo.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import com.demo.dto.EmployeeDTO;
//import com.demo.service.EmployeeService;
//
//@RestController
//@RequestMapping("/employees")
//public class EmployeeController {
//
//    @Autowired
//    EmployeeService service;
//
//    @GetMapping
//    public List<EmployeeDTO> getAllEmployees() {
//
//        return service.getAllEmployees();
//
//    }
//
//    @GetMapping("/{id}")
//    public EmployeeDTO getEmployee(@PathVariable int id) {
//
//        return service.getEmployee(id);
//
//    }
//    
//    @GetMapping("/getEmp")
//    public EmployeeDTO getEmployee1(@RequestParam("id") int id) {
//
//        return service.getEmployee(id);
//
//    }
//
//    @PostMapping
//    public EmployeeDTO addEmployee(@RequestBody EmployeeDTO dto) {
//
//        return service.addEmployee(dto);
//
//    }
//    @GetMapping("/add")
//    public EmployeeDTO addEmployeeGet(@RequestParam("id") int id,
//    		@RequestParam("name") String name,@RequestParam("salary") double salary) {
//
//        return service.addEmployee(new EmployeeDTO(id, name, salary));
//
//    }
//    
//    @PostMapping("/addPost")
//    public EmployeeDTO addEmployeePost(@RequestParam("id") int id,
//    		@RequestParam("name") String name,@RequestParam("salary") double salary) {
//
//        return service.addEmployee(new EmployeeDTO(id, name, salary));
//
//    }
//
//    @PutMapping("/{id}")
//    public EmployeeDTO updateEmployee(@PathVariable int id,
//                                      @RequestBody EmployeeDTO dto) {
//
//        return service.updateEmployee(id, dto);
//
//    }
//    
//    @GetMapping("/updateEmp")
//    public EmployeeDTO updateEmployee1(@RequestParam("id") int id,
//    		@RequestParam("name") String name,@RequestParam("salary") double salary) {
//
//        return service.updateEmployee(id, new EmployeeDTO(id, name, salary));
//
//    }
//
//    @DeleteMapping("/{id}")
//    public String deleteEmployee(@PathVariable int id) {
//
//        return service.deleteEmployee(id);
//
//    }
//    
//    @GetMapping("/delEmp")
//    public String deleteEmployee1(@RequestParam("id") int id) {
//
//        return service.deleteEmployee(id);
//
//    }
//
//}