package com.demo.dto.EmployeeDTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public class EmployeeDTO {

    @Positive(message = "ID must be a positive number")
    private int id;

    @NotBlank(message = "Employee name cannot be blank")
    private String name;

    @Positive(message = "Salary must be greater than zero")
    private double salary;

    public EmployeeDTO() {
    }

    public EmployeeDTO(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}