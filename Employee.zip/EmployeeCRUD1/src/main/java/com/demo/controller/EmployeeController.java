package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.dto.EmployeeDTO.EmployeeDTO;
import com.demo.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    EmployeeService service;

    // GET: Returns 200 OK
    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getAllEmployees() {
        List<EmployeeDTO> employees = service.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

    // GET ONE: Returns 200 OK or 404 Not Found
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable int id) {
        EmployeeDTO employee = service.getEmployee(id);
        
        if (employee == null) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(employee);
    }

    // POST: Returns 201 Created. (@Valid checks the DTO rules)
    @PostMapping
    public ResponseEntity<EmployeeDTO> addEmployee(@Valid @RequestBody EmployeeDTO dto) {
        EmployeeDTO savedEmployee = service.addEmployee(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedEmployee);
    }

    // PUT: Returns 200 OK or 404 Not Found. (@Valid checks the DTO rules)
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable int id, 
                                                      @Valid @RequestBody EmployeeDTO dto) {
        EmployeeDTO updatedEmployee = service.updateEmployee(id, dto);
        
        if (updatedEmployee == null) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(updatedEmployee);
    }

    // DELETE: Returns 204 No Content
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable int id) {
        service.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }
}