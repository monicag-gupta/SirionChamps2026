package com.projectmanagement.dto;

import lombok.Data;

@Data

public class AuthResponse {

    public AuthResponse(String token) {
		super();
		this.token = token;
	}

	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}