package com.projectmanagement.service.impl;

import com.projectmanagement.entity.Project;
import com.projectmanagement.repository.ProjectRepository;
import com.projectmanagement.service.ProjectService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;

    public ProjectServiceImpl(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Override
    public Project saveProject(Project project) {
        return projectRepository.save(project);
    }

    @Override
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    @Override
    public Project getProjectById(Long pid) {
        return projectRepository.findById(pid)
                .orElseThrow(() -> new RuntimeException("Project not found with id : " + pid));
    }

    @Override
    public Project updateProject(Long pid, Project project) {

        Project existing = getProjectById(pid);

        existing.setPname(project.getPname());
        existing.setDuration(project.getDuration());
        existing.setPmngr(project.getPmngr());
        existing.setpLanguage(project.getpLanguage());

        return projectRepository.save(existing);
    }

    @Override
    public void deleteProject(Long pid) {

        Project project = getProjectById(pid);

        projectRepository.delete(project);
    }
}