package com.projectmanagement.service;

import com.projectmanagement.entity.Team;

import java.util.List;

public interface TeamService {

    Team saveTeam(Team team);

    List<Team> getAllTeams();

    Team getTeamById(Long id);

    void deleteTeam(Long id);

    List<Team> getEmployeesByProject(Long pid);

    List<Team> getProjectsByEmployee(Long eid);
}