package com.projectmanagement.service;

import com.projectmanagement.entity.Project;

import java.util.List;

public interface ProjectService {

    Project saveProject(Project project);

    List<Project> getAllProjects();

    Project getProjectById(Long pid);

    Project updateProject(Long pid, Project project);

    void deleteProject(Long pid);

}