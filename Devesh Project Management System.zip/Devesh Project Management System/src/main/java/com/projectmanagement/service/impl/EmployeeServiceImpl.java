package com.projectmanagement.service.impl;

import com.projectmanagement.entity.Employee;
import com.projectmanagement.repository.EmployeeRepository;
import com.projectmanagement.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployeeById(Long eid) {
        return employeeRepository.findById(eid)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    @Override
    public Employee updateEmployee(Long eid, Employee employee) {

        Employee existing = getEmployeeById(eid);

        existing.setEname(employee.getEname());

        return employeeRepository.save(existing);
    }

    @Override
    public void deleteEmployee(Long eid) {
        employeeRepository.deleteById(eid);
    }
}