package com.projectmanagement.service;

import com.projectmanagement.entity.Employee;

import java.util.List;

public interface EmployeeService {

    Employee saveEmployee(Employee employee);

    List<Employee> getAllEmployees();

    Employee getEmployeeById(Long eid);

    Employee updateEmployee(Long eid, Employee employee);

    void deleteEmployee(Long eid);
}