package com.projectmanagement.service.impl;

import com.projectmanagement.entity.Skill;
import com.projectmanagement.repository.SkillRepository;
import com.projectmanagement.service.SkillService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillServiceImpl implements SkillService {

    private final SkillRepository skillRepository;

    public SkillServiceImpl(SkillRepository skillRepository) {
        this.skillRepository = skillRepository;
    }

    @Override
    public Skill saveSkill(Skill skill) {
        return skillRepository.save(skill);
    }

    @Override
    public List<Skill> getAllSkills() {
        return skillRepository.findAll();
    }

    @Override
    public Skill getSkillById(Long id) {
        return skillRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Skill not found with id: " + id));
    }

    @Override
    public Skill updateSkill(Long id, Skill skill) {

        Skill existing = getSkillById(id);

        existing.setsName(skill.getsName());
        existing.setEmployee(skill.getEmployee());

        return skillRepository.save(existing);
    }

    @Override
    public void deleteSkill(Long id) {

        Skill skill = getSkillById(id);

        skillRepository.delete(skill);
    }

    @Override
    public List<Skill> getSkillsByEmployee(Long eid) {

        return skillRepository.findByEmployeeEid(eid);
    }
}