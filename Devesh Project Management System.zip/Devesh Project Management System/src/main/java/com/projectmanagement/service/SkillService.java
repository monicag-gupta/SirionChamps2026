package com.projectmanagement.service;

import com.projectmanagement.entity.Skill;

import java.util.List;

public interface SkillService {

    Skill saveSkill(Skill skill);

    List<Skill> getAllSkills();

    Skill getSkillById(Long id);

    Skill updateSkill(Long id, Skill skill);

    void deleteSkill(Long id);

    List<Skill> getSkillsByEmployee(Long eid);
}