package com.projectmanagement.service.impl;

import com.projectmanagement.entity.Team;
import com.projectmanagement.repository.TeamRepository;
import com.projectmanagement.service.TeamService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamServiceImpl implements TeamService {

    private final TeamRepository teamRepository;

    public TeamServiceImpl(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    @Override
    public Team saveTeam(Team team) {
        return teamRepository.save(team);
    }

    @Override
    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    @Override
    public Team getTeamById(Long id) {
        return teamRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Team assignment not found with id: " + id));
    }

    @Override
    public void deleteTeam(Long id) {

        Team team = getTeamById(id);

        teamRepository.delete(team);
    }

    @Override
    public List<Team> getEmployeesByProject(Long pid) {

        return teamRepository.findByProjectPid(pid);
    }

    @Override
    public List<Team> getProjectsByEmployee(Long eid) {

        return teamRepository.findByEmployeeEid(eid);
    }
}