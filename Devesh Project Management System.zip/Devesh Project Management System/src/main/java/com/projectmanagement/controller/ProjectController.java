package com.projectmanagement.controller;

import com.projectmanagement.entity.Project;
import com.projectmanagement.service.ProjectService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @PostMapping
    public Project saveProject(@RequestBody Project project) {
        return projectService.saveProject(project);
    }

    @GetMapping
    public List<Project> getAllProjects() {
        return projectService.getAllProjects();
    }

    @GetMapping("/{pid}")
    public Project getProject(@PathVariable Long pid) {
        return projectService.getProjectById(pid);
    }

    @PutMapping("/{pid}")
    public Project updateProject(@PathVariable Long pid,
                                 @RequestBody Project project) {
        return projectService.updateProject(pid, project);
    }

    @DeleteMapping("/{pid}")
    public String deleteProject(@PathVariable Long pid) {
        projectService.deleteProject(pid);
        return "Project deleted successfully.";
    }
}