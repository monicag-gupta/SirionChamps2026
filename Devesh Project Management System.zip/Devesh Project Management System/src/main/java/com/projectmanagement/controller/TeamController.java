package com.projectmanagement.controller;

import com.projectmanagement.entity.Team;
import com.projectmanagement.service.TeamService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/team")
public class TeamController {

    private final TeamService teamService;

    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }

    @PostMapping
    public Team assignEmployee(@RequestBody Team team) {
        return teamService.saveTeam(team);
    }

    @GetMapping
    public List<Team> getAllAssignments() {
        return teamService.getAllTeams();
    }

    @GetMapping("/project/{pid}")
    public List<Team> getEmployeesByProject(@PathVariable Long pid) {
        return teamService.getEmployeesByProject(pid);
    }

    @GetMapping("/employee/{eid}")
    public List<Team> getProjectsByEmployee(@PathVariable Long eid) {
        return teamService.getProjectsByEmployee(eid);
    }

    @DeleteMapping("/{id}")
    public String deleteAssignment(@PathVariable Long id) {
        teamService.deleteTeam(id);
        return "Assignment deleted successfully.";
    }
}