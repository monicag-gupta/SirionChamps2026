package com.projectmanagement.controller;

import com.projectmanagement.entity.Employee;
import com.projectmanagement.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping
    public Employee saveEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @GetMapping("/{eid}")
    public Employee getEmployee(@PathVariable Long eid) {
        return employeeService.getEmployeeById(eid);
    }

    @PutMapping("/{eid}")
    public Employee updateEmployee(@PathVariable Long eid,
                                   @RequestBody Employee employee) {
        return employeeService.updateEmployee(eid, employee);
    }

    @DeleteMapping("/{eid}")
    public String deleteEmployee(@PathVariable Long eid) {
        employeeService.deleteEmployee(eid);
        return "Employee deleted successfully.";
    }
}