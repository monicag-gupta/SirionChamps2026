package com.projectmanagement.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "projects")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pid;

    @Column(nullable = false)
    private String pname;

    private Integer duration;

    private String pmngr;

    private String pLanguage;

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getPmngr() {
		return pmngr;
	}

	public void setPmngr(String pmngr) {
		this.pmngr = pmngr;
	}

	public String getpLanguage() {
		return pLanguage;
	}

	public void setpLanguage(String pLanguage) {
		this.pLanguage = pLanguage;
	}
	

	
}