package com.example.demo.client;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.entity.Employee;


@FeignClient(name="READ-SERVICE")
public interface ReadClient {


    @GetMapping("/read")
    List<Employee> getAll();


}