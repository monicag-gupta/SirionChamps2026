package com.example.demo.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;


@FeignClient(name="CREATE-SERVICE")
public interface CreateClient {


    @PostMapping("/create")
    Employee save(@RequestBody Employee employee);


}
