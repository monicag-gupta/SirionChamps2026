package com.example.demo.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;


@FeignClient(name="UPDATE-SERVICE")
public interface UpdateClient {


    @PutMapping("/update/{id}")
    Employee update(
            @PathVariable Integer id,
            @RequestBody Employee employee
    );

}