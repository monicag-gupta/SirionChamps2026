package com.example.demo.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


@FeignClient(name="DELETE-SERVICE")
public interface DeleteClient {


    @DeleteMapping("/delete/{id}")
    String delete(
            @PathVariable Integer id
    );

}