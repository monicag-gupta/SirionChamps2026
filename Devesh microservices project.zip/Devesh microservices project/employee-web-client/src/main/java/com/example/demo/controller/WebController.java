package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.client.*;
import com.example.demo.entity.Employee;



@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class WebController {


    @Autowired
    private ReadClient readClient;


    @Autowired
    private CreateClient createClient;
    
    @Autowired
    private UpdateClient updateClient;


    @Autowired
    private DeleteClient deleteClient;



    @GetMapping("/employees")
    public List<Employee> getEmployees(){

        return readClient.getAll();

    }



    @PostMapping("/employees")
    public Employee save(
            @RequestBody Employee employee
    ){

        return createClient.save(employee);

    }
    
    
    @PutMapping("/employees/{id}")
    public Employee update(
            @PathVariable Integer id,
            @RequestBody Employee employee
    ) {

        return updateClient.update(id, employee);

    }



    @DeleteMapping("/employees/{id}")
    public String delete(
            @PathVariable Integer id
    ){

        return deleteClient.delete(id);

    }


}