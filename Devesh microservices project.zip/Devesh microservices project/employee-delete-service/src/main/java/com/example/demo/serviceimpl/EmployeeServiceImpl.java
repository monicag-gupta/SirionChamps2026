package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository repository;

    @Override
    public String deleteEmployee(Integer id) {

        if (repository.existsById(id)) {

            repository.deleteById(id);

            return "Employee Deleted Successfully.";

        }

        return "Employee Not Found.";

    }

}