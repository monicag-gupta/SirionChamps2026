package com.example.demo.service;

public interface EmployeeService {

    String deleteEmployee(Integer id);

}