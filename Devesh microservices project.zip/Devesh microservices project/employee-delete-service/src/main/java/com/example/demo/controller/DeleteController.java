package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/delete")
public class DeleteController {

    @Autowired
    private EmployeeService employeeService;

    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Integer id) {

        return employeeService.deleteEmployee(id);

    }

}
