package com.example.demo.service;

import com.example.demo.entity.Employee;

public interface EmployeeService {

    Employee updateEmployee(Integer id, Employee employee);

}