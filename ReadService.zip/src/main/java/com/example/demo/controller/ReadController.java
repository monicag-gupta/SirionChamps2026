package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;
import com.example.demo.service.ReadService;


@RestController
@RequestMapping("/users")
public class ReadController {


    @Autowired
    private ReadService service;


    @GetMapping
    public List<User> getAllUsers(){

        return service.getAllUsers();

    }


    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id){

        return service.getUserById(id);

    }

}