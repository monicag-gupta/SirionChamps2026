package com.example.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;



@Service
public class ReadService {


    @Autowired
    private UserRepository repository;



    public List<User> getAllUsers(){

        return repository.findAll();

    }



    public User getUserById(Long id){

        return repository.findById(id)
                .orElse(null);

    }

}