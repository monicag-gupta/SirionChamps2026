package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;
import com.example.demo.feign.*;


@RestController
@RequestMapping("/api")
public class UserController {


    @Autowired
    private CreateClient createClient;


    @Autowired
    private ReadClient readClient;


    @Autowired
    private UpdateClient updateClient;


    @Autowired
    private DeleteClient deleteClient;


    @PostMapping("/users")
    public User create(@RequestBody User user){

        return createClient.createUser(user);

    }


    @GetMapping("/users")
    public List<User> read(){

        return readClient.getUsers();

    }


    @PutMapping("/users/{id}")
    public User update(
            @PathVariable Long id,
            @RequestBody User user){

        return updateClient.updateUser(id,user);

    }


    @DeleteMapping("/users/{id}")
    public String delete(
            @PathVariable Long id){

        return deleteClient.deleteUser(id);

    }

}