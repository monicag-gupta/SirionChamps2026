package com.example.demo.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name="DeleteService")
public interface DeleteClient {


    @DeleteMapping("/users/{id}")
    String deleteUser(
            @PathVariable Long id
    );

}