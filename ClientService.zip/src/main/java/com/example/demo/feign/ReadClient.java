package com.example.demo.feign;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;



@FeignClient(name="ReadService")
public interface ReadClient {


    @GetMapping("/users")
    List<User> getUsers();



    @GetMapping("/users/{id}")
    User getUser(@PathVariable Long id);

}