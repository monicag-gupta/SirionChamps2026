package com.example.demo.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;

@FeignClient(name="UpdateService")
public interface UpdateClient {


    @PutMapping("/users/{id}")
    User updateUser(
            @PathVariable Long id,
            @RequestBody User user
    );

}