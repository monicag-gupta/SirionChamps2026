package com.example.demo.feign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;



@FeignClient(name="CreateService")
public interface CreateClient {


    @PostMapping("/users")
    User createUser(@RequestBody User user);

}