import os
import jpype
import jpype.imports

# Get absolute path to the bundled JAR file
JAR_PATH = os.path.join(os.path.dirname(__file__), "..", "filelister.jar")

def _init_jvm():
    """Starts the JVM if it isn't already running."""
    if not jpype.isJVMStarted():
        # Start JVM with the classpath set to our JAR
        jpype.startJVM(classpath=[os.path.abspath(JAR_PATH)])

def list_files():
    """Calls the underlying Java method to list files in the current working directory."""
    _init_jvm()
    
    # Import the Java class via JPype
    FileLister = jpype.JClass("com.example.FileLister")
    
    # Invoke the Java static method
    FileLister.printCurrentDirectoryFiles()