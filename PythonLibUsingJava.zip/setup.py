from setuptools import setup, find_packages

setup(
    name="jfilelister",
    version="0.1.0",
    description="A Python library powered by Java to list directory contents.",
    author="Your Name",
    packages=find_packages(),
    # Include non-python files (the .jar file)
    package_data={"": ["*.jar"]},
    include_package_data=True,
    install_requires=[
        "jpype1>=1.4.0",
    ],
    python_requires=">=3.8",
)