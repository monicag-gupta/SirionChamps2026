package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/delete")
public class DeleteController {

    @Autowired
    UserRepository repo;

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id){

        repo.deleteById(id);

        return "Deleted";

    }

}
