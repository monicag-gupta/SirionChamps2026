package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.User;

@FeignClient(name="UpdateClient")
public interface UpdateFeign {

    @PutMapping("/update/{id}")
    User update(@PathVariable Integer id,
                @RequestBody User user);

}
