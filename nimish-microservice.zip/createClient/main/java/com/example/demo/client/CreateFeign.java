package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.User;

@FeignClient(name = "CreateClient")
public interface CreateFeign {

    @PostMapping("/create")
    User save(@RequestBody User user);

}
