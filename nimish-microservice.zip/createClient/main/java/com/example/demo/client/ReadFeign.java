package com.example.demo.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.model.User;

@FeignClient(name="ReadClient")
public interface ReadFeign {

    @GetMapping("/read")
    List<User> getAll();

}
