package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="DeleteClient")
public interface DeleteFeign {

    @DeleteMapping("/delete/{id}")
    String delete(@PathVariable Integer id);

}
