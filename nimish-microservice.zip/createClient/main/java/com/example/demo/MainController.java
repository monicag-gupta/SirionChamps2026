package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.client.CreateFeign;
import com.example.demo.client.DeleteFeign;
import com.example.demo.client.ReadFeign;
import com.example.demo.client.UpdateFeign;
import com.example.demo.model.User;

@RestController
@RequestMapping("/api")
public class MainController {


    @Autowired
    CreateFeign createFeign;

    @Autowired
    ReadFeign readFeign;

    @Autowired
    UpdateFeign updateFeign;

    @Autowired
    DeleteFeign deleteFeign;



    // READ ALL USERS
    @GetMapping("/users")
    public List<User> getUsers(){

        return readFeign.getAll();

    }



    // CREATE USER
    @PostMapping("/save")
    public User save(@RequestBody User user){

        return createFeign.save(user);

    }



    // UPDATE USER
    @PutMapping("/update/{id}")
    public User update(
            @PathVariable Integer id,
            @RequestBody User user){

        return updateFeign.update(id,user);

    }



    // DELETE USER
    @DeleteMapping("/delete/{id}")
    public String delete(
            @PathVariable Integer id){

        return deleteFeign.delete(id);

    }

}