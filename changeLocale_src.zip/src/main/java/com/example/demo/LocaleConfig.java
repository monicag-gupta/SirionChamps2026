package com.example.demo;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
import org.springframework.context.annotation.Bean;

import java.util.Locale;

@Configuration
public class LocaleConfig {


    @Bean
    public LocaleResolver localeResolver() {

        AcceptHeaderLocaleResolver resolver =
                new AcceptHeaderLocaleResolver();

        // Default locale if browser locale is not supported
        resolver.setDefaultLocale(Locale.ENGLISH);

        return resolver;
    }
}
