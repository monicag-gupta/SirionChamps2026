package com.example.demo;

import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.*;

import java.util.Locale;
import java.util.Map;

@RestController
public class GreetingController {


    private final MessageSource messageSource;


    public GreetingController(MessageSource messageSource) {
        this.messageSource = messageSource;
    }


    @GetMapping("/hello")
    public Map<String, String> hello(
            Locale locale) {


        String greeting =
                messageSource.getMessage(
                        "greeting",
                        null,
                        locale
                );


        String welcome =
                messageSource.getMessage(
                        "welcome",
                        null,
                        locale
                );


        String language =
                messageSource.getMessage(
                        "language",
                        null,
                        locale
                );


        return Map.of(
                "detectedLocale",
                locale.toLanguageTag(),

                "language",
                language,

                "greeting",
                greeting,

                "welcome",
                welcome
        );
    }
}
