package com.example.clientinfoservice.config;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.nio.charset.StandardCharsets;

@Configuration
public class MessageConfig {

    @Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        // Sets the base name for files: src/main/resources/messages_*.properties
        messageSource.setBasename("messages"); 
        messageSource.setDefaultEncoding(StandardCharsets.UTF_8.name());
        // Fallback to messages_en.properties if the requested locale isn't available
        messageSource.setUseCodeAsDefaultMessage(true); 
        return messageSource;
    }
}