package com.example.clientinfoservice.service;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.model.CityResponse;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.net.InetAddress;

@Service
public class GeoLocationService {

    private DatabaseReader dbReader;

    @PostConstruct
    public void init() {
        try {
            InputStream dbStream = new ClassPathResource("GeoLite2-City.mmdb").getInputStream();
            this.dbReader = new DatabaseReader.Builder(dbStream).build();
        } catch (Exception e) {
            System.err.println("GeoIP Database file not found or failed to load. " + e.getMessage());
        }
    }

    public String getClientIp(HttpServletRequest request) {
        // Handles requests behind proxies/load balancers
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        
        // Handle comma-separated multiple IPs (takes the first real client IP)
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        
        return ip;
    }

    public CityResponse getCityResponse(String ipAddress) {
        try {
            InetAddress ip = InetAddress.getByName(ipAddress);
            return dbReader.city(ip);
        } catch (Exception e) {
            return null; // Return null if IP is localhost (127.0.0.1) or unresolvable
        }
    }
}