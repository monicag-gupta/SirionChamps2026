package com.example.clientinfoservice.controller;

import com.example.clientinfoservice.dto.ClientInfoResponse;
import com.example.clientinfoservice.service.GeoLocationService;
import com.maxmind.geoip2.model.CityResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;

@RestController
@RequestMapping("/api/v1/client-info")
public class ClientInfoController {

    private final GeoLocationService geoLocationService;
    private final MessageSource messageSource;

    // Inject MessageSource
    public ClientInfoController(GeoLocationService geoLocationService, MessageSource messageSource) {
        this.geoLocationService = geoLocationService;
        this.messageSource = messageSource;
    }

    @GetMapping
    public ResponseEntity<ClientInfoResponse> getClientInfo(HttpServletRequest request, Locale locale) {
        String clientIp = geoLocationService.getClientIp(request);
        
        Double latitude = null;
        Double longitude = null;

        CityResponse cityResponse = geoLocationService.getCityResponse(clientIp);
        if (cityResponse != null && cityResponse.getLocation() != null) {
            latitude = cityResponse.getLocation().getLatitude();
            longitude = cityResponse.getLocation().getLongitude();
        }

        // Fetch localized message based on client Locale
        String welcomeMessage = messageSource.getMessage("welcome.message", null, locale);

        ClientInfoResponse response = new ClientInfoResponse(
                clientIp, 
                latitude, 
                longitude, 
                locale.toString(), 
                welcomeMessage
        );
        
        return ResponseEntity.ok(response);
    }
}