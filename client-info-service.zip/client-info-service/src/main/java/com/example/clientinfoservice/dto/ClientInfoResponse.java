package com.example.clientinfoservice.dto;

public class ClientInfoResponse {
    private String ipAddress;
    private Double latitude;
    private Double longitude;
    private String locale;
    private String localizedWelcomeMessage; // New field

    public ClientInfoResponse(String ipAddress, Double latitude, Double longitude, String locale, String localizedWelcomeMessage) {
        this.ipAddress = ipAddress;
        this.latitude = latitude;
        this.longitude = longitude;
        this.locale = locale;
        this.localizedWelcomeMessage = localizedWelcomeMessage;
    }

    // Getters and Setters
    public String getIpAddress() { return ipAddress; }
    public Double getLatitude() { return latitude; }
    public Double getLongitude() { return longitude; }
    public String getLocale() { return locale; }
    public String getLocalizedWelcomeMessage() { return localizedWelcomeMessage; }
}