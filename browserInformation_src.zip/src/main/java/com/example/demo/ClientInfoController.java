package com.example.demo;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ClientInfoController {

    @GetMapping("/")
    public String helloWorld(Model model) {

        return "hello-world";
    }


    @GetMapping("/client-info")
    public String clientInfo(
            HttpServletRequest request,
            @RequestParam(required = false) Double latitude,
            @RequestParam(required = false) Double longitude,
            @RequestHeader(value = "Accept-Language",
                    required = false) String locale,
            Model model) {

        model.addAttribute("ipAddress", getClientIp(request));
        model.addAttribute("locale", locale);
        model.addAttribute("latitude", latitude);
        model.addAttribute("longitude", longitude);

        return "client-info";
    }


    private String getClientIp(HttpServletRequest request) {

        String forwarded =
                request.getHeader("X-Forwarded-For");

        if (forwarded != null && !forwarded.isEmpty()) {
            return forwarded.split(",")[0];
        }

        return request.getRemoteAddr();
    }
}
