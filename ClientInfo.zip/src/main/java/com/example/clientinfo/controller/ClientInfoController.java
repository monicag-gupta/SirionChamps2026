package com.example.clientinfo.controller;


import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.*;

import java.util.Locale;
import java.util.Map;


@RestController
@RequestMapping("/api")
public class ClientInfoController {


    private final MessageSource messageSource;


    public ClientInfoController(MessageSource messageSource) {
        this.messageSource = messageSource;
    }


    @GetMapping("/welcome")
    public Map<String,String> welcome(Locale locale) {


        String message =
                messageSource.getMessage(
                        "welcome.message",
                        null,
                        locale
                );


        return Map.of(
                "locale", locale.toString(),
                "message", message
        );
    }
}