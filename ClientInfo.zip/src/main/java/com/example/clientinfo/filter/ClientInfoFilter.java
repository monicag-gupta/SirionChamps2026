package com.example.clientinfo.filter;


import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;


import java.io.IOException;


@Component
public class ClientInfoFilter extends OncePerRequestFilter {


    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {


        String ip = getClientIp(request);

        String locale =
                request.getHeader("Accept-Language");


        String latitude =
                request.getHeader("X-Client-Latitude");


        String longitude =
                request.getHeader("X-Client-Longitude");


        String userAgent =
                request.getHeader("User-Agent");


        System.out.println("=======================");
        System.out.println("Client IP       : " + ip);
        System.out.println("Locale          : " + locale);
        System.out.println("Latitude        : " + latitude);
        System.out.println("Longitude       : " + longitude);
        System.out.println("User Agent      : " + userAgent);
        System.out.println("=======================");


        filterChain.doFilter(request,response);
    }



    private String getClientIp(HttpServletRequest request){

        String forwarded =
                request.getHeader("X-Forwarded-For");


        if(forwarded != null){
            return forwarded.split(",")[0];
        }


        return request.getRemoteAddr();
    }

}