from flask import Flask, jsonify

app = Flask(__name__)

# List of employee dictionaries
emps = [
    {"name": "Alice", "sal": 50000},
    {"name": "Bob", "sal": 60000}
]

# GET: Display all employees
@app.route("/emps", methods=["GET"])
def get_employees():
    return jsonify(emps)

# POST: Add a new employee using URL parameters
@app.route("/emps/<name>/<int:sal>", methods=["POST"])
def add_employee(name, sal):
    emp = {
        "name": name,
        "sal": sal
    }

    emps.append(emp)

    return jsonify({
        "message": "Employee added successfully",
        "employee": emp
    })

if __name__ == "__main__":
    app.run(debug=True)