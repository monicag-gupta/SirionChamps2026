from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

app = FastAPI(title="Employee Information API")


# Employee Model
class Employee(BaseModel):
    id: int
    name: str
    department: str
    salary: float


# Temporary Employee List
employees = [
    {
        "id": 1,
        "name": "Alice",
        "department": "HR",
        "salary": 50000
    },
    {
        "id": 2,
        "name": "Bob",
        "department": "IT",
        "salary": 65000
    },
    {
        "id": 3,
        "name": "Charlie",
        "department": "Finance",
        "salary": 55000
    }
]


# -----------------------------------
# Home Route
# -----------------------------------
@app.get("/")
def home():
    return {"Application": "Employee Information API"}


# -----------------------------------
# Get All Employees
# -----------------------------------
@app.get("/employees")
def get_employees():
    return employees


# -----------------------------------
# Get Employee by ID
# -----------------------------------
@app.get("/employees/{employee_id}")
def get_employee(employee_id: int):
    for emp in employees:
        if emp["id"] == employee_id:
            return emp

    raise HTTPException(status_code=404, detail="Employee not found")


# -----------------------------------
# Add Employee
# -----------------------------------
@app.post("/employees")
def add_employee(employee: Employee):
    employees.append(employee.model_dump())
    return {
        "message": "Employee added successfully",
        "employee": employee
    }


# -----------------------------------
# Search by Department
# Example:
# /search?department=IT
# -----------------------------------
@app.get("/search")
def search_employee(department: str):
    result = []

    for emp in employees:
        if emp["department"].lower() == department.lower():
            result.append(emp)

    return result


# -----------------------------------
# Custom Response
# -----------------------------------
@app.get("/application-info")
def application_info():
    return JSONResponse(
        status_code=200,
        content={
            "application": "Employee Information API",
            "version": "1.0",
            "developer": "Your Name"
        }
    )