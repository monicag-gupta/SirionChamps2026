from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

# Database Connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root@123",
    database="college"
)

cursor = conn.cursor()

# ------------------- GET All Courses -------------------

@app.route("/courses", methods=["GET"])
def get_courses():
    cursor.execute("SELECT * FROM course")
    data = cursor.fetchall()

    courses = []
    for row in data:
        courses.append({
            "id": row[0],
            "name": row[1],
            "duration": row[2],
            "fee": float(row[3])
        })

    return jsonify(courses)

# ------------------- GET Course by ID -------------------

@app.route("/courses/<int:id>", methods=["GET"])
def get_course(id):
    cursor.execute("SELECT * FROM course WHERE id=%s", (id,))
    row = cursor.fetchone()

    if row:
        return jsonify({
            "id": row[0],
            "name": row[1],
            "duration": row[2],
            "fee": float(row[3])
        })

    return jsonify({"message": "Course not found"}), 404

# ------------------- ADD Course -------------------

@app.route("/courses", methods=["POST"])
def add_course():
    data = request.get_json()

    sql = "INSERT INTO course(name, duration, fee) VALUES(%s,%s,%s)"
    values = (data["name"], data["duration"], data["fee"])

    cursor.execute(sql, values)
    conn.commit()

    return jsonify({"message": "Course added successfully"})

# ------------------- UPDATE Course -------------------

@app.route("/courses/<int:id>", methods=["PUT"])
def update_course(id):
    data = request.get_json()

    sql = """
    UPDATE course
    SET name=%s, duration=%s, fee=%s
    WHERE id=%s
    """

    values = (
        data["name"],
        data["duration"],
        data["fee"],
        id
    )

    cursor.execute(sql, values)
    conn.commit()

    return jsonify({"message": "Course updated successfully"})

# ------------------- DELETE Course -------------------

@app.route("/courses/<int:id>", methods=["DELETE"])
def delete_course(id):

    cursor.execute("DELETE FROM course WHERE id=%s", (id,))
    conn.commit()

    return jsonify({"message": "Course deleted successfully"})

# -------------------

if __name__ == "__main__":
    app.run(debug=True)



# created database in mysql from this query


# CREATE DATABASE college;

# USE college;

# CREATE TABLE course (
#     id INT AUTO_INCREMENT PRIMARY KEY,
#     name VARCHAR(100),
#     duration VARCHAR(50),
#     fee DECIMAL(10,2)
# );