package com.example.projectmanagement.controller;


import com.example.projectmanagement.dto.TeamDTO;
import com.example.projectmanagement.entity.Team;
import com.example.projectmanagement.service.TeamService;


import jakarta.validation.Valid;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/teams")
public class TeamController {


    private final TeamService teamService;



    public TeamController(
            TeamService teamService
    ){

        this.teamService = teamService;

    }





    @GetMapping
    public List<Team> getAll(){

        return teamService.getAllTeams();

    }





    @PostMapping
    public ResponseEntity<?> add(
            @Valid @RequestBody TeamDTO dto
    ){

        Team team =
                teamService.addTeam(dto);



        if(team == null){

            return ResponseEntity
                    .badRequest()
                    .body(
                    "Invalid Employee or Project ID"
                    );

        }


        return ResponseEntity.ok(team);

    }





    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Integer id
    ){

        if(teamService.deleteTeam(id)){

            return ResponseEntity.ok(
                    "Team deleted"
            );

        }


        return ResponseEntity
                .notFound()
                .build();

    }

}
