package com.example.projectmanagement.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;



@Entity
@Table(name = "Skills")
public class Skill {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer sid;



    @NotBlank(message = "Skill name is required")
    private String sName;



    @ManyToOne
    @JoinColumn(name = "eid")
    private Employee employee;





    public Skill(){

    }




    public Skill(Integer sid, String sName, Employee employee) {

        this.sid = sid;
        this.sName = sName;
        this.employee = employee;

    }




    public Integer getSid() {
        return sid;
    }


    public void setSid(Integer sid) {
        this.sid = sid;
    }



    public String getsName() {
        return sName;
    }


    public void setsName(String sName) {
        this.sName = sName;
    }



    public Employee getEmployee() {
        return employee;
    }


    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

}
