package com.example.projectmanagement.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;



public class SkillDTO {



    @NotBlank(message = "Skill name is required")
    private String sName;



    @NotNull(message = "Employee ID is required")
    private Integer eid;





    public SkillDTO(){

    }





    public SkillDTO(String sName, Integer eid){

        this.sName = sName;
        this.eid = eid;

    }





    public String getSName(){

        return sName;

    }





    public void setSName(String sName){

        this.sName = sName;

    }





    public Integer getEid(){

        return eid;

    }





    public void setEid(Integer eid){

        this.eid = eid;

    }

}
