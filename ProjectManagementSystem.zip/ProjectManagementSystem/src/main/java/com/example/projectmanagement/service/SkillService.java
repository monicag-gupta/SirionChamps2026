package com.example.projectmanagement.service;


import com.example.projectmanagement.dto.SkillDTO;
import com.example.projectmanagement.entity.Employee;
import com.example.projectmanagement.entity.Skill;

import com.example.projectmanagement.repository.EmployeeRepository;
import com.example.projectmanagement.repository.SkillRepository;


import org.springframework.stereotype.Service;


import java.util.List;



@Service
public class SkillService {


    private final SkillRepository skillRepository;

    private final EmployeeRepository employeeRepository;



    public SkillService(
            SkillRepository skillRepository,
            EmployeeRepository employeeRepository
    ){

        this.skillRepository = skillRepository;
        this.employeeRepository = employeeRepository;

    }





    public List<Skill> getAllSkills(){

        return skillRepository.findAll();

    }





    public Skill addSkill(SkillDTO dto){


        Employee employee =
                employeeRepository
                .findById(dto.getEid())
                .orElse(null);



        if(employee == null){

            return null;

        }



        Skill skill = new Skill();

        skill.setsName(dto.getSName());

        skill.setEmployee(employee);



        return skillRepository.save(skill);

    }





    public boolean deleteSkill(Integer id){

        if(skillRepository.existsById(id)){

            skillRepository.deleteById(id);

            return true;

        }

        return false;

    }

}
