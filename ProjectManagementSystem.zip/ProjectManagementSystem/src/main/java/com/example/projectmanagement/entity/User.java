package com.example.projectmanagement.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;



@Entity
@Table(name = "Users")
public class User {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer uid;




    @Column(unique = true)
    @NotBlank(message = "Username is required")
    private String username;




    @NotBlank(message = "Password is required")
    private String password;




    @NotBlank(message = "Role is required")
    private String role;





    public User(){

    }





    public User(Integer uid, String username, String password, String role) {

        this.uid = uid;
        this.username = username;
        this.password = password;
        this.role = role;

    }





    public Integer getUid() {
        return uid;
    }


    public void setUid(Integer uid) {
        this.uid = uid;
    }



    public String getUsername() {
        return username;
    }


    public void setUsername(String username) {
        this.username = username;
    }




    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }




    public String getRole() {
        return role;
    }


    public void setRole(String role) {
        this.role = role;
    }


}
