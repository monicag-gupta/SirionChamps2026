package com.example.projectmanagement.controller;


import com.example.projectmanagement.dto.LoginRequest;
import com.example.projectmanagement.dto.LoginResponse;
import com.example.projectmanagement.service.AuthService;


import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/auth")
public class AuthController {


    private final AuthService authService;


    public AuthController(AuthService authService){

        this.authService = authService;

    }




    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody LoginRequest request
    ){

        LoginResponse response =
                authService.login(request);



        if(response == null){

            return ResponseEntity
                    .status(401)
                    .body("Invalid username or password");

        }



        return ResponseEntity.ok(response);

    }

}
