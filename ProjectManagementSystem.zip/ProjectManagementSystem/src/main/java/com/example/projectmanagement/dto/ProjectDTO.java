package com.example.projectmanagement.dto;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;



public class ProjectDTO {


    @NotBlank(message = "Project name is required")
    @Size(min = 3, max = 150)
    private String pname;



    @NotNull(message = "Duration is required")
    @Min(value = 1, message = "Duration must be greater than 0")
    private Integer duration;



    @NotNull(message = "Project Manager ID is required")
    private Integer pmngr;



    @NotBlank(message = "Programming language is required")
    private String PLanguage;




    public ProjectDTO(){

    }





    public ProjectDTO(String pname,
                      Integer duration,
                      Integer pmngr,
                      String PLanguage){

        this.pname = pname;
        this.duration = duration;
        this.pmngr = pmngr;
        this.PLanguage = PLanguage;

    }




    public String getPname(){

        return pname;

    }




    public void setPname(String pname){

        this.pname = pname;

    }




    public Integer getDuration(){

        return duration;

    }




    public void setDuration(Integer duration){

        this.duration = duration;

    }




    public Integer getPmngr(){

        return pmngr;

    }




    public void setPmngr(Integer pmngr){

        this.pmngr = pmngr;

    }




    public String getPLanguage(){

        return PLanguage;

    }




    public void setPLanguage(String PLanguage){

        this.PLanguage = PLanguage;

    }

}
