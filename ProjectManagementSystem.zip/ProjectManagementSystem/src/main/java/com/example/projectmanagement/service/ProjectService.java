package com.example.projectmanagement.service;


import com.example.projectmanagement.entity.Employee;
import com.example.projectmanagement.entity.Project;

import com.example.projectmanagement.dto.ProjectDTO;

import com.example.projectmanagement.repository.EmployeeRepository;
import com.example.projectmanagement.repository.ProjectRepository;


import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class ProjectService {


    private final ProjectRepository projectRepository;

    private final EmployeeRepository employeeRepository;



    public ProjectService(
            ProjectRepository projectRepository,
            EmployeeRepository employeeRepository
    ){

        this.projectRepository = projectRepository;
        this.employeeRepository = employeeRepository;

    }





    public List<Project> getAllProjects(){

        return projectRepository.findAll();

    }





    public Project getProjectById(Integer id){

        return projectRepository
                .findById(id)
                .orElse(null);

    }





    public Project addProject(ProjectDTO dto){


        Employee manager =
                employeeRepository
                .findById(dto.getPmngr())
                .orElse(null);



        if(manager == null){

            return null;

        }


        Project project = new Project();


        project.setPname(dto.getPname());

        project.setDuration(dto.getDuration());

        project.setPLanguage(dto.getPLanguage());

        project.setPmngr(manager);



        return projectRepository.save(project);

    }





    public Project updateProject(
            Integer id,
            ProjectDTO dto
    ){


        Project project =
                projectRepository
                .findById(id)
                .orElse(null);



        if(project == null){

            return null;

        }


        Employee manager =
                employeeRepository
                .findById(dto.getPmngr())
                .orElse(null);



        if(manager == null){

            return null;

        }



        project.setPname(dto.getPname());

        project.setDuration(dto.getDuration());

        project.setPLanguage(dto.getPLanguage());

        project.setPmngr(manager);



        return projectRepository.save(project);

    }





    public boolean deleteProject(Integer id){

        if(projectRepository.existsById(id)){

            projectRepository.deleteById(id);

            return true;

        }


        return false;

    }

}
