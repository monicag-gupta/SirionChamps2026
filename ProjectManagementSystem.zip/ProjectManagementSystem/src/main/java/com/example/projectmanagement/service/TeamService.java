package com.example.projectmanagement.service;


import com.example.projectmanagement.dto.TeamDTO;
import com.example.projectmanagement.entity.Employee;
import com.example.projectmanagement.entity.Project;
import com.example.projectmanagement.entity.Team;


import com.example.projectmanagement.repository.EmployeeRepository;
import com.example.projectmanagement.repository.ProjectRepository;
import com.example.projectmanagement.repository.TeamRepository;


import org.springframework.stereotype.Service;


import java.util.List;



@Service
public class TeamService {


    private final TeamRepository teamRepository;

    private final EmployeeRepository employeeRepository;

    private final ProjectRepository projectRepository;




    public TeamService(
            TeamRepository teamRepository,
            EmployeeRepository employeeRepository,
            ProjectRepository projectRepository
    ){

        this.teamRepository = teamRepository;
        this.employeeRepository = employeeRepository;
        this.projectRepository = projectRepository;

    }




    public List<Team> getAllTeams(){

        return teamRepository.findAll();

    }





    public Team addTeam(TeamDTO dto){


        Employee employee =
                employeeRepository
                .findById(dto.getEid())
                .orElse(null);



        Project project =
                projectRepository
                .findById(dto.getPid())
                .orElse(null);



        if(employee == null || project == null){

            return null;

        }



        Team team = new Team();


        team.setEmployee(employee);

        team.setProject(project);



        return teamRepository.save(team);

    }





    public boolean deleteTeam(Integer id){

        if(teamRepository.existsById(id)){

            teamRepository.deleteById(id);

            return true;

        }

        return false;

    }

}
