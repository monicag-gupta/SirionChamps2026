package com.example.projectmanagement.entity;


import jakarta.persistence.*;



@Entity
@Table(name = "Team")
public class Team {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer tid;



    @ManyToOne
    @JoinColumn(name = "eid")
    private Employee employee;



    @ManyToOne
    @JoinColumn(name = "pid")
    private Project project;





    public Team(){

    }





    public Team(Integer tid, Employee employee, Project project) {

        this.tid = tid;
        this.employee = employee;
        this.project = project;

    }





    public Integer getTid() {
        return tid;
    }


    public void setTid(Integer tid) {
        this.tid = tid;
    }



    public Employee getEmployee() {
        return employee;
    }


    public void setEmployee(Employee employee) {
        this.employee = employee;
    }




    public Project getProject() {
        return project;
    }


    public void setProject(Project project) {
        this.project = project;
    }


}
