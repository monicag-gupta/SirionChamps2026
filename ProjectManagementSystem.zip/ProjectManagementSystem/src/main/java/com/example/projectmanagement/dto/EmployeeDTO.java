package com.example.projectmanagement.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;



public class EmployeeDTO {


    @NotBlank(message = "Employee name is required")
    @Size(min = 3, max = 100)
    private String ename;




    public EmployeeDTO(){

    }




    public EmployeeDTO(String ename){

        this.ename = ename;

    }




    public String getEname(){

        return ename;

    }




    public void setEname(String ename){

        this.ename = ename;

    }

}
