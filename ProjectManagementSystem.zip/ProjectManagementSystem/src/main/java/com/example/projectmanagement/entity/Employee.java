package com.example.projectmanagement.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;


@Entity
@Table(name = "Emp")
public class Employee {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer eid;


    @NotBlank(message = "Employee name is required")
    @Size(min = 3, max = 100)
    private String ename;



    public Employee() {

    }



    public Employee(Integer eid, String ename) {
        this.eid = eid;
        this.ename = ename;
    }



    public Integer getEid() {
        return eid;
    }


    public void setEid(Integer eid) {
        this.eid = eid;
    }


    public String getEname() {
        return ename;
    }


    public void setEname(String ename) {
        this.ename = ename;
    }

}
