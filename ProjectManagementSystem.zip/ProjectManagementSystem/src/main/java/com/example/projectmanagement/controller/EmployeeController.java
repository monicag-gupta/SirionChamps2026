package com.example.projectmanagement.controller;


import com.example.projectmanagement.entity.Employee;
import com.example.projectmanagement.service.EmployeeService;


import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/employees")
public class EmployeeController {


    private final EmployeeService employeeService;



    public EmployeeController(
            EmployeeService employeeService
    ){

        this.employeeService = employeeService;

    }





    @GetMapping
    public List<Employee> getAll(){

        return employeeService.getAllEmployees();

    }





    @GetMapping("/{id}")
    public ResponseEntity<?> getById(
            @PathVariable Integer id
    ){

        Employee employee =
                employeeService
                .getEmployeeById(id);



        if(employee == null){

            return ResponseEntity
                    .notFound()
                    .build();

        }


        return ResponseEntity.ok(employee);

    }





    @PostMapping
    public ResponseEntity<Employee> add(
            @Valid @RequestBody Employee employee
    ){

        return ResponseEntity
                .ok(
                    employeeService
                    .addEmployee(employee)
                );

    }





    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @PathVariable Integer id,
            @Valid @RequestBody Employee employee
    ){

        Employee updated =
                employeeService
                .updateEmployee(id,employee);



        if(updated == null){

            return ResponseEntity
                    .notFound()
                    .build();

        }


        return ResponseEntity.ok(updated);

    }





    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Integer id
    ){

        if(employeeService.deleteEmployee(id)){

            return ResponseEntity.ok(
                    "Employee deleted"
            );

        }


        return ResponseEntity
                .notFound()
                .build();

    }

}
