package com.example.projectmanagement.service;


import com.example.projectmanagement.entity.Project;
import com.example.projectmanagement.entity.Team;

import com.example.projectmanagement.repository.ProjectRepository;
import com.example.projectmanagement.repository.TeamRepository;


import org.springframework.stereotype.Service;


import java.util.List;



@Service
public class ReportService {


    private final ProjectRepository projectRepository;

    private final TeamRepository teamRepository;



    public ReportService(
            ProjectRepository projectRepository,
            TeamRepository teamRepository
    ){

        this.projectRepository = projectRepository;
        this.teamRepository = teamRepository;

    }




    public List<Project> getAllProjects(){

        return projectRepository.findAll();

    }





    public List<Team> getProjectTeam(Integer pid){


        return teamRepository
                .findAll()
                .stream()
                .filter(
                    team ->
                    team.getProject()
                    .getPid()
                    .equals(pid)
                )
                .toList();

    }




    public List<Project> getProjectsByLanguage(
            String language
    ){

        return projectRepository
                .findAll()
                .stream()
                .filter(
                    project ->
                    project.getPLanguage()
                    .equalsIgnoreCase(language)
                )
                .toList();

    }





    public Project getLongestProject(){

        return projectRepository
                .findAll()
                .stream()
                .max(
                    (p1,p2) ->
                    p1.getDuration()
                    .compareTo(
                    p2.getDuration()
                    )
                )
                .orElse(null);

    }

}
