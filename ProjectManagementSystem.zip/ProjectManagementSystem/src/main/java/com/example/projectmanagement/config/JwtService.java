package com.example.projectmanagement.config;


import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;



@Service
public class JwtService {


    @Value("${jwt.secret}")
    private String secretKey;


    @Value("${jwt.expiration}")
    private long expirationTime;




    private Key getSigningKey(){


        return Keys.hmacShaKeyFor(
                secretKey.getBytes(StandardCharsets.UTF_8)
        );

    }





    public String generateToken(
            String username,
            String role
    ){


        return Jwts.builder()

                .setSubject(username)

                .claim("role", role)

                .setIssuedAt(new Date())


                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                + expirationTime
                        )
                )


                .signWith(
                        getSigningKey(),
                        SignatureAlgorithm.HS256
                )


                .compact();

    }






    public String extractUsername(
            String token
    ){


        return Jwts.parserBuilder()

                .setSigningKey(getSigningKey())

                .build()

                .parseClaimsJws(token)

                .getBody()

                .getSubject();

    }







    public boolean validateToken(
            String token
    ){


        try{


            Jwts.parserBuilder()

                    .setSigningKey(getSigningKey())

                    .build()

                    .parseClaimsJws(token);



            return true;


        }
        catch(Exception e){


            return false;

        }

    }


}
