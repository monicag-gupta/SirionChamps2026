package com.example.projectmanagement.service;


import com.example.projectmanagement.entity.Employee;
import com.example.projectmanagement.repository.EmployeeRepository;

import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class EmployeeService {


    private final EmployeeRepository employeeRepository;


    public EmployeeService(
            EmployeeRepository employeeRepository
    ){
        this.employeeRepository = employeeRepository;
    }



    public List<Employee> getAllEmployees(){

        return employeeRepository.findAll();

    }



    public Employee getEmployeeById(Integer id){

        return employeeRepository
                .findById(id)
                .orElse(null);

    }



    public Employee addEmployee(Employee employee){

        return employeeRepository.save(employee);

    }



    public Employee updateEmployee(
            Integer id,
            Employee employee
    ){


        Employee existing =
                employeeRepository
                .findById(id)
                .orElse(null);



        if(existing == null){
            return null;
        }


        existing.setEname(
                employee.getEname()
        );


        return employeeRepository.save(existing);

    }




    public boolean deleteEmployee(Integer id){

        if(employeeRepository.existsById(id)){

            employeeRepository.deleteById(id);

            return true;
        }

        return false;

    }

}
