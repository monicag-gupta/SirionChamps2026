package com.example.projectmanagement.controller;


import com.example.projectmanagement.entity.Project;
import com.example.projectmanagement.entity.Team;
import com.example.projectmanagement.service.ReportService;


import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/reports")
public class ReportController {


    private final ReportService reportService;



    public ReportController(
            ReportService reportService
    ){

        this.reportService = reportService;

    }





    @GetMapping("/projects")
    public List<Project> allProjects(){

        return reportService.getAllProjects();

    }





    @GetMapping("/project/{pid}/team")
    public List<Team> projectTeam(
            @PathVariable Integer pid
    ){

        return reportService
                .getProjectTeam(pid);

    }





    @GetMapping("/language/{language}")
    public List<Project> byLanguage(
            @PathVariable String language
    ){

        return reportService
                .getProjectsByLanguage(language);

    }





    @GetMapping("/longest-project")
    public Project longestProject(){

        return reportService
                .getLongestProject();

    }

}
