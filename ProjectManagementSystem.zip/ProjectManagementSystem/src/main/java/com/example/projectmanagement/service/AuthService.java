package com.example.projectmanagement.service;


import com.example.projectmanagement.config.JwtService;
import com.example.projectmanagement.dto.LoginRequest;
import com.example.projectmanagement.dto.LoginResponse;
import com.example.projectmanagement.entity.User;
import com.example.projectmanagement.repository.UserRepository;

import org.springframework.stereotype.Service;


@Service
public class AuthService {


    private final UserRepository userRepository;
    private final JwtService jwtService;


    public AuthService(
            UserRepository userRepository,
            JwtService jwtService
    ){
        this.userRepository = userRepository;
        this.jwtService = jwtService;
    }



    public LoginResponse login(LoginRequest request){


        User user = userRepository
                .findByUsername(request.getUsername())
                .orElse(null);



        if(user == null){
            return null;
        }


        // Plain text password comparison
        if(!user.getPassword()
                .equals(request.getPassword())){

            return null;
        }



        String token =
                jwtService.generateToken(
                        user.getUsername(),
                        user.getRole()
                );


        return new LoginResponse(token);

    }

}
