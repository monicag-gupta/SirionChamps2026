package com.example.projectmanagement.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;



@Entity
@Table(name = "Project")
public class Project {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pid;


    @NotBlank(message = "Project name is required")
    @Size(min = 3, max = 150)
    private String pname;



    @Min(value = 1, message = "Duration must be greater than 0")
    private Integer duration;



    @ManyToOne
    @JoinColumn(name = "pmngr")
    @NotNull(message = "Project manager is required")
    private Employee pmngr;



    @NotBlank(message = "Programming language is required")
    private String PLanguage;




    public Project() {

    }



    public Project(Integer pid, String pname, Integer duration,
                   Employee pmngr, String PLanguage) {

        this.pid = pid;
        this.pname = pname;
        this.duration = duration;
        this.pmngr = pmngr;
        this.PLanguage = PLanguage;

    }




    public Integer getPid() {
        return pid;
    }


    public void setPid(Integer pid) {
        this.pid = pid;
    }



    public String getPname() {
        return pname;
    }


    public void setPname(String pname) {
        this.pname = pname;
    }



    public Integer getDuration() {
        return duration;
    }


    public void setDuration(Integer duration) {
        this.duration = duration;
    }



    public Employee getPmngr() {
        return pmngr;
    }


    public void setPmngr(Employee pmngr) {
        this.pmngr = pmngr;
    }



    public String getPLanguage() {
        return PLanguage;
    }


    public void setPLanguage(String PLanguage) {
        this.PLanguage = PLanguage;
    }


}
