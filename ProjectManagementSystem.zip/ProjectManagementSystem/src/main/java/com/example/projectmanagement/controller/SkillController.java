package com.example.projectmanagement.controller;


import com.example.projectmanagement.dto.SkillDTO;
import com.example.projectmanagement.entity.Skill;
import com.example.projectmanagement.service.SkillService;


import jakarta.validation.Valid;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/skills")
public class SkillController {


    private final SkillService skillService;



    public SkillController(
            SkillService skillService
    ){

        this.skillService = skillService;

    }





    @GetMapping
    public List<Skill> getAll(){

        return skillService.getAllSkills();

    }





    @PostMapping
    public ResponseEntity<?> add(
            @Valid @RequestBody SkillDTO dto
    ){

        Skill skill =
                skillService.addSkill(dto);



        if(skill == null){

            return ResponseEntity
                    .badRequest()
                    .body("Invalid Employee ID");

        }


        return ResponseEntity.ok(skill);

    }





    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Integer id
    ){

        if(skillService.deleteSkill(id)){

            return ResponseEntity.ok(
                    "Skill deleted"
            );

        }


        return ResponseEntity
                .notFound()
                .build();

    }

}
