package com.example.projectmanagement.dto;


import jakarta.validation.constraints.NotNull;



public class TeamDTO {


    @NotNull(message = "Employee ID is required")
    private Integer eid;



    @NotNull(message = "Project ID is required")
    private Integer pid;





    public TeamDTO(){

    }





    public TeamDTO(Integer eid, Integer pid){

        this.eid = eid;
        this.pid = pid;

    }





    public Integer getEid(){

        return eid;

    }





    public void setEid(Integer eid){

        this.eid = eid;

    }





    public Integer getPid(){

        return pid;

    }





    public void setPid(Integer pid){

        this.pid = pid;

    }

}
