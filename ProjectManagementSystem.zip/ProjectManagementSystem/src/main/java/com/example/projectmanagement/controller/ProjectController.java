package com.example.projectmanagement.controller;


import com.example.projectmanagement.dto.ProjectDTO;
import com.example.projectmanagement.entity.Project;
import com.example.projectmanagement.service.ProjectService;


import jakarta.validation.Valid;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;



@RestController
@RequestMapping("/projects")
public class ProjectController {



    private final ProjectService projectService;



    public ProjectController(
            ProjectService projectService
    ){

        this.projectService = projectService;

    }





    @GetMapping
    public List<Project> getAll(){

        return projectService.getAllProjects();

    }





    @GetMapping("/{id}")
    public ResponseEntity<?> getById(
            @PathVariable Integer id
    ){

        Project project =
                projectService
                .getProjectById(id);



        if(project == null){

            return ResponseEntity
                    .notFound()
                    .build();

        }


        return ResponseEntity.ok(project);

    }





    @PostMapping
    public ResponseEntity<?> add(
            @Valid @RequestBody ProjectDTO dto
    ){

        Project project =
                projectService.addProject(dto);



        if(project == null){

            return ResponseEntity
                    .badRequest()
                    .body("Invalid Project Manager ID");

        }


        return ResponseEntity.ok(project);

    }





    @PutMapping("/{id}")
    public ResponseEntity<?> update(
            @PathVariable Integer id,
            @Valid @RequestBody ProjectDTO dto
    ){

        Project project =
                projectService
                .updateProject(id,dto);



        if(project == null){

            return ResponseEntity
                    .notFound()
                    .build();

        }


        return ResponseEntity.ok(project);

    }





    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(
            @PathVariable Integer id
    ){

        if(projectService.deleteProject(id)){

            return ResponseEntity.ok(
                    "Project deleted"
            );

        }


        return ResponseEntity
                .notFound()
                .build();

    }

}
