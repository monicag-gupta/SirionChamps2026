package com.example.demo.dto;


public record CustomerRequest(

        String name,

        String email,

        String phone,

        Double latitude,

        Double longitude,

        String locale

) {
}
