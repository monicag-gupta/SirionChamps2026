package com.example.demo.service;


import java.util.List;

import com.example.demo.dto.CustomerRequest;
import com.example.demo.model.Customer;

public interface CustomerService {

    Customer saveCustomer(CustomerRequest request, String ipAddress);

    List<Customer> getAllCustomers();

    Customer getCustomerById(Long id);

    void deleteCustomer(Long id);

}
