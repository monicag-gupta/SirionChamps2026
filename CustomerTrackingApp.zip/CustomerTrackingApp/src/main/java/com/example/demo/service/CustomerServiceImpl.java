package com.example.demo.service;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.dto.CustomerRequest;
import com.example.demo.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

    private final List<Customer> customers = new ArrayList<>();

    private Long nextId = 1L;

    @Override
    public Customer saveCustomer(CustomerRequest request, String ipAddress) {

        Customer customer = new Customer();

        customer.setId(nextId++);

        customer.setName(request.name());

        customer.setEmail(request.email());

        customer.setPhone(request.phone());

        customer.setLatitude(request.latitude());

        customer.setLongitude(request.longitude());

        customer.setLocale(request.locale());

        customer.setIpAddress(ipAddress);

        customer.setSubmittedAt(LocalDateTime.now());

        customers.add(customer);

        return customer;
    }

    @Override
    public List<Customer> getAllCustomers() {

        return customers;

    }

    @Override
    public Customer getCustomerById(Long id) {

        for (Customer customer : customers) {

            if (customer.getId().equals(id)) {

                return customer;

            }

        }

        return null;

    }

    @Override
    public void deleteCustomer(Long id) {

        customers.removeIf(customer -> customer.getId().equals(id));

    }

}
