class StringReverser:

    def reverse_words(self, text: str) -> str:

        words = text.strip().split()
        return " ".join(words[::-1])



reverser = StringReverser()
input_str = input("Enter the string:")
output_str = reverser.reverse_words(input_str)

print(f"Input string : '{input_str}'")
print(f"Expected Output : '{output_str}'")