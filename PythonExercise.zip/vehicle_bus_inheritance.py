class Vehicle:

    def __init__(self, name: str, seating_capacity: int):
        self.name = name
        self.seating_capacity = seating_capacity

    def fare(self) -> float:

        return self.seating_capacity * 100


class Bus(Vehicle):

    def __init__(self, name: str = "School Bus", seating_capacity: int = 50):

        super().__init__(name, seating_capacity)

    def fare(self) -> float:

        base_fare = super().fare()

        total_fare = base_fare + (base_fare * 0.10)
        return total_fare



school_bus = Bus(name="School Bus", seating_capacity=50)
print(f"Total Bus fare is: {school_bus.fare()}")
