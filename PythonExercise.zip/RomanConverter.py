class RomanConverter:

    def int_to_roman(self, num: int) -> str:

        val_map = [
            (1000, "M"),
            (900, "CM"),
            (500, "D"),
            (400, "CD"),
            (100, "C"),
            (90, "XC"),
            (50, "L"),
            (40, "XL"),
            (10, "X"),
            (9, "IX"),
            (5, "V"),
            (4, "IV"),
            (1, "I"),
        ]

        roman_num = ""
        for val, symbol in val_map:
            while num >= val:
                roman_num += symbol
                num -= val
        return roman_num

    def roman_to_int(self, roman: str) -> int:
        roman_map = {
            "I": 1,
            "V": 5,
            "X": 10,
            "L": 50,
            "C": 100,
            "D": 500,
            "M": 1000,
        }
        total = 0
        prev_value = 0

        for char in reversed(roman.upper()):
            curr_value = roman_map[char]
            if curr_value < prev_value:
                total -= curr_value
            else:
                total += curr_value
            prev_value = curr_value

        return total


converter = RomanConverter()
num = int(input("Enter the number:"))
print(converter.int_to_roman(num))  
romanNum = input("Enter the roman number:")
print(converter.roman_to_int(romanNum))  